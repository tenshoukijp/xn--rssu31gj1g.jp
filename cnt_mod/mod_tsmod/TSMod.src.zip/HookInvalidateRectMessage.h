#pragma once


BOOL Hook_InvalidateRectMessage(HWND, CONST RECT *, BOOL);
