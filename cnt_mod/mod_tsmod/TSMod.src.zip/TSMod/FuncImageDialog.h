#pragma once

#pragma pack(1)

void FuncOpenImageDialog();
void FuncCloseImageDialog();

