#pragma once

#pragma pack(1)

#include "WinTarget.h"

BOOL ToCopyClipboard( LPTSTR szData );