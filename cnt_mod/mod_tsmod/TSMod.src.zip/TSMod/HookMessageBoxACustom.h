#pragma once


int Hook_MessageBoxACustom( HWND, PCSTR, PCSTR, UINT, int);
