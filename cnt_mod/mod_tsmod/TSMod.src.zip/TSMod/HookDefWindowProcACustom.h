#pragma once


LRESULT Hook_DefWindowProcACustom( HWND, UINT, WPARAM, LPARAM );
