#pragma once

#pragma pack(1)

int FuncOkCancelDialog(char *szInfoDialogMessage);
void FuncInfoDialog(char *);
void FuncAssertDialog(char *);
void FuncConfirmDialog(char *);