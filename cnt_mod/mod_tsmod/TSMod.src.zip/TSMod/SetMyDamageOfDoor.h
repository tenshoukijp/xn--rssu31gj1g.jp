#pragma once

void SetPatchMyDamageOfDoor();