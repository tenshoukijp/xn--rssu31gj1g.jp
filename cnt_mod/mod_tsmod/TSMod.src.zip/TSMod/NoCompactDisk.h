#pragma once
#pragma pack(1)

#include <windows.h>

void NoCompactDisk();
void CheckValidLogicalDrive();
void CheckValidLogicalVolumeInfomation(char *szDriveName);
