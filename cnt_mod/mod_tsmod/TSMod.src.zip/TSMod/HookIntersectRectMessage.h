#pragma once


BOOL Hook_IntersectRectMessage(LPRECT, CONST RECT *, CONST RECT *);
