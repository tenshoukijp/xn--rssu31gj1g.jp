#pragma once

void rewriteDefaultBattleCommand();