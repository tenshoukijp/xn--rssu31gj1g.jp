#pragma once


extern vector<int> vListIsseiKougekiMembers;
extern void MakeIsseikougekiMembers(int iBushouID, int iTargetID);