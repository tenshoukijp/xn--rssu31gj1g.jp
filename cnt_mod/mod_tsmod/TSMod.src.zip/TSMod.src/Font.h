#pragma once

void setFontCustomCheck();