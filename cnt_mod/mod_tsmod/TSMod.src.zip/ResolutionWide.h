#pragma once

void setWideResolution();