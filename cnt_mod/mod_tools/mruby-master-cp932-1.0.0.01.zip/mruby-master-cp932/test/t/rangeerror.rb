##
# RangeError ISO Test

assert('RangeError', '15.2.26') do
  assert_equal Class, RangeError.class
end
