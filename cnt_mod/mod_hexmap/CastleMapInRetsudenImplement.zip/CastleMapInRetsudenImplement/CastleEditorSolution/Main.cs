﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Collections;
using System.Diagnostics;


class CastleMainProgram
{
    [STAThread]
    static void Main()
    {
        Application.EnableVisualStyles();
        CastleMapInRetsudenViewerImplement f = new CastleMapInRetsudenViewerImplement();
        f.OnBeginPaint(100, "");
        Application.Run(f);
    }
}