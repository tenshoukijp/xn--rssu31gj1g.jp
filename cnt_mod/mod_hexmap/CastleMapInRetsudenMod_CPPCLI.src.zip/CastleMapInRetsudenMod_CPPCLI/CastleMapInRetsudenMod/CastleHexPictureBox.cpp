#include "CastleMapInRetsudenImplement.h"

void CastleMapInRetsudenViewerImplement::RegistPictureBoxes()
{
	// ���n
	this->basePictureImg = gcnew array<Image^>(iColMax * iRowMax);

	// ���
	this->wallPictureImg = gcnew array<Image^>(iColMax * iRowMax);

	// �{�ہE�ȗցE�΂� ��
	this->ridePictureImg = gcnew array<Image^>(iColMax * iRowMax);

}

Point CastleMapInRetsudenViewerImplement::GetPicturePos(int col, int row)
{
	if (row % 2 == 0)
	{
		return Point(iLeftStandingPos + col * iTipImageSize, iTopStandingPos + row * iTipImageSize);
	}
	else
	{
		return Point(iLeftStandingPos + (iTipImageSize / 2) + col * iTipImageSize, iTopStandingPos + row * iTipImageSize);
	}
}

void CastleMapInRetsudenViewerImplement::RePaintBaseTips()
{

	// �R���{�{�b�N�X�őI��������́u�`�b�v���X�g�v���擾
	ArrayList ^csOneHexMapTipsList = safe_cast<ArrayList^>(csAllHexMapArray[GetSelectedHexMapID()]);

	for (int i = 0; i < iRowMax * iColMax; i++)
	{
		// �x�[�X
		Byte tip = safe_cast<Byte>(csOneHexMapTipsList[i]);
		Image ^baseImage = baseImages[tip];
		this->basePictureImg[i] = baseImage;
	}

}

void CastleMapInRetsudenViewerImplement::RePaintWallTips()
{

	// �R���{�{�b�N�X�őI��������́u�`�b�v���X�g�v���擾
	ArrayList ^csOneHexMapTipsList = safe_cast<ArrayList^>(csAllHexMapArray[GetSelectedHexMapID()]);

	for (int i = 0; i < iRowMax * iColMax; i++)
	{

		// �E�H�[��
		Byte tip = safe_cast<Byte>(csOneHexMapTipsList[i + (iColMax * iRowMax) * 1]);
		Image ^wallImage = wallImages[tip];
		this->wallPictureImg[i] = wallImage;
	}
}

void CastleMapInRetsudenViewerImplement::RePaintRideTips()
{

	// �R���{�{�b�N�X�őI��������́u�`�b�v���X�g�v���擾
	ArrayList ^csOneHexMapTipsList = safe_cast<ArrayList^>(csAllHexMapArray[GetSelectedHexMapID()]);

	for (int i = 0; i < iRowMax * iColMax; i++)
	{

		// ���C�h
		Byte tip = safe_cast<Byte>(csOneHexMapTipsList[i + (iColMax * iRowMax) * 2]);
		Image ^rideImage = rideImages[tip];
		this->ridePictureImg[i] = rideImage;
	}
}

void CastleMapInRetsudenViewerImplement::RePaintResultTips()
{
	Bitmap ^result = gcnew Bitmap(imgDialogBackground, 320, 304);

	// �x�[�X�ƂȂ�C���[�W
	Graphics ^g = Graphics::FromImage(result);

	int i = 0;
	for (int row = 0; row < iRowMax; row++)
	{
		for (int col = 0; col < iColMax; col++)
		{

			Point pos = GetPicturePos(col, row);
			//------------- �d�˕\��
			// �y�n�d��
			g->DrawImage(this->basePictureImg[i], pos.X, pos.Y, iTipImageSize, iTipImageSize);

			if (safe_cast<int>(this->wallPictureImg[i]->Tag) != 0xFF)
			{ // �����ł͂Ȃ�
				// �Ǐd��
				g->DrawImage(this->wallPictureImg[i], pos.X, pos.Y, iTipImageSize, iTipImageSize);
			}
			if (safe_cast<int>(this->ridePictureImg[i]->Tag) != 0xFF)
			{ // �����ł͂Ȃ�
				// ���d��
				g->DrawImage(this->ridePictureImg[i], pos.X, pos.Y, iTipImageSize, iTipImageSize);
			}

			i++;
		}
	}

	// �d�˂��̂Ŕj��
	delete g;

	this->resultPicture = result;
}

void CastleMapInRetsudenViewerImplement::RePaintAllTips()
{
	RePaintBaseTips();
	RePaintWallTips();
	RePaintRideTips();
	RePaintResultTips();

	// SaveImage();

}
/*
void CastleMapInRetsudenViewerImplement::SaveImage()
{
	try
	{
		//�摜���쐬����
		Bitmap ^bmp = gcnew Bitmap(this->resultPicture);

		//PNG�`���ŕۑ�����
		bmp->Save(GetCastleImgTmpFileName(), System::Drawing::Imaging::ImageFormat::Png);

		//��Еt��
		delete bmp;
	}
	catch (Exception ^e)
	{
		System::Windows::Forms::MessageBox::Show(e->Message);
	}
}

void CastleMapInRetsudenViewerImplement::SetCastleImgTmpFileName()
{
	tmpFileName = System::IO::Path::GetTempPath() + R"(\)" + "CastleMapInRetsudenMod.tmp";
}

String ^CastleMapInRetsudenViewerImplement::GetCastleImgTmpFileName()
{
	return tmpFileName;
}
*/