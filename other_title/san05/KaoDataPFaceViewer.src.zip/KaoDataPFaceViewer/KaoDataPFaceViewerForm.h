#pragma once;

#include "KaoDataStruct.h"

using namespace std;
using namespace System;
using namespace System::Drawing;
using namespace System::Windows::Forms;
using namespace System::Collections::Generic;
using namespace System::Diagnostics;
using namespace System::IO;

extern void ImportKaoDataFileToProgramStruct(char *szInputFileName);
extern Image^ GetBushouFaceImage(int iBushouID);


ref class KaoDataPFaceViewerForm : public Form {
	static List<PictureBox^>^ pbList;
	static List<Label^>^ lbList;
	static int iBushouStartPosition = 0;

	FileSystemWatcher^ watcher;

	static char *szTargetFile = "kaodatap.s5";
	static String^ outDirName = "kao_3bit";

public:
	KaoDataPFaceViewerForm() {
		this->KeyPreview = true; // �L�[�C�x���g�ɂ��ẮA�t�H�[���őS�Ď󂯎��

		iBushouStartPosition = 0;

		ImportKaoDataFileToProgramStruct(szTargetFile);
		this->StartPosition = ::FormStartPosition::Manual;
		this->Width = 840;
		this->Height = 1010;
		this->MaximizeBox = false;

		this->KeyDown += gcnew KeyEventHandler(this, &KaoDataPFaceViewerForm::form_KeyDown);

		InitPictureBoxList();

		InitFileWatcher();
	}
private:
	void InitPictureBoxList() {

		this->SuspendLayout();

		pbList = gcnew List<PictureBox^>();
		lbList = gcnew List<Label^>();

		int iBushouID = 0;
		for (int y = 0; y < 10; y++) {
			for (int x = 0; x < 10; x++) {
				PictureBox^ pb = gcnew PictureBox();
				pb->Width = FaceWidth;
				pb->Height = FaceHeight;
				pb->Left = x * 80 + 10;
				pb->Top = y * 96 + 10;
				pb->Image = GetBushouFaceImage(iBushouID);
				pb->Tag = iBushouID;
				pbList->Add(pb);
				this->Controls->Add(pb);

				Label^ lb = gcnew Label();
				lb->Width = FaceWidth;
				lb->Height = 13;
				lb->Left = pb->Left;
				lb->Top = pb->Bottom + 1;
				lb->Text = (iBushouID + 1).ToString();
				lb->TextAlign = ContentAlignment::TopCenter;
				lbList->Add(lb);
				this->Controls->Add(lb);

				iBushouID++;
			}
		}

		this->ResumeLayout();
	}

	void UpdatePictureBoxList(int iStartBushouID) {

		this->SuspendLayout();

		int iBushouID = iStartBushouID;
		for (int i = 0; i < pbList->Count; i++) {

			PictureBox^ pb = pbList[i];
			pb->Image = GetBushouFaceImage(iBushouID);

			Label^ lb = lbList[i];
			lb->Text = (iBushouID + 1).ToString();

			iBushouID++;
		}

		this->ResumeLayout();
	}

	void InitFileWatcher() {
		watcher = gcnew FileSystemWatcher();
		//�Ď�����f�B���N�g�����w��
		watcher->Path = Application::StartupPath;
		// ����̃t�@�C���݂̂̊Ď�
		watcher->Filter = gcnew String(szTargetFile);

		// �ŏI�������ݓ����̕ύX���Ď�
		watcher->NotifyFilter = NotifyFilters::LastWrite;

		//�T�u�f�B���N�g���͊Ď����Ȃ�
		watcher->IncludeSubdirectories = false;

		// UI�X���b�h�Ƀ}�[�V�������O
		watcher->SynchronizingObject = this;

		//�C�x���g�n���h���̒ǉ�
		watcher->Changed += gcnew FileSystemEventHandler(this, &KaoDataPFaceViewerForm::watcher_Changed);

		watcher->EnableRaisingEvents = true;

	}

	void form_KeyDown(Object^ sender, KeyEventArgs^ e) {
		auto code = e->KeyCode;
		// �O�̃f�[�^�Ƃ����悤�ȈӖ����w���L�[�{�[�h��������
		if (code == Keys::Left || code == Keys::Up || code == Keys::PageUp) {
			iBushouStartPosition -= 100;
		}
		// ���̃f�[�^�Ƃ����悤�ȈӖ����w���L�[�{�[�h��������
		else if (code == Keys::Right || code == Keys::Down || code == Keys::PageDown) {
			iBushouStartPosition += 100;
		}	

		else if (code == Keys::Home) {
			iBushouStartPosition = 0;
		}
		else if (code == Keys::End) {
			iBushouStartPosition = 700;
		}

		if (iBushouStartPosition < 0) {
			iBushouStartPosition = 0;
		}
		if (iBushouStartPosition > 700) {
			iBushouStartPosition = 700;
		}

		if (code == Keys::O) {
			auto ret = MessageBox::Show("�S�Ă̊���t�@�C���ւƏo�͂��܂����H", "�m�F", ::MessageBoxButtons::YesNo);
			if (ret == ::DialogResult::Yes) {
				if (!Directory::Exists(outDirName)) {
					Directory::CreateDirectory(outDirName);
				}

				OutputAllFaceToBmp();
			}
		}

		else if (code == Keys::I) {
			String^ importer = "KaoDataPFaceImporter.exe";
			if ( File::Exists(importer) ) {
				auto ret = MessageBox::Show("�S�Ă̊��" + gcnew String(szTargetFile) + "�ւƎ捞���܂����H", "�m�F", ::MessageBoxButtons::YesNo);
				if (ret == ::DialogResult::Yes) {
					Process::Start(importer);
				}
			}
		}

		UpdatePictureBoxList(iBushouStartPosition);
	}

	void OutputAllFaceToBmp() {
		int error_cnt = 0;
		for (int b = 0; b < BUSHOU_NUM; b++) {
			Image^ img = GetBushouFaceImage(b);
			String^ filefullpath = String::Format(outDirName + "\\{0:D4}.bmp", b + 1); // �t�@�C���ɂ��鎞�́A�P�������l
			try {
				img->Save(filefullpath);
			}
			catch (Exception^ e) {
				error_cnt++;
				MessageBox::Show(e->Message + "\n" + filefullpath);
			}
		}

		MessageBox::Show("����");
	}

	void watcher_Changed(Object^ sender, FileSystemEventArgs ^ e) {
		System::Diagnostics::Trace::WriteLine(e->Name);
		// ��f�[�^�S�̂�ǂݒ���
		ImportKaoDataFileToProgramStruct(szTargetFile);
		// �\���X�V
		UpdatePictureBoxList(iBushouStartPosition);
	}

};
