#pragma once


#include <windows.h>


#define BUF_LINE 500
#define BUF_CHRS 4096

using PFNOUTPUT = int(_cdecl *)(HWND hwnd, const char *);
using PFNGETWINDOWHANDLE = HWND(_cdecl *)(HWND hHidemaru);
extern int hCurHidemaruWndHandle;
extern "C" void _stdcall SetSharedMessage(char *szmsg);

unsigned __stdcall OutputSharedMessage(void *);

extern char szBufList[BUF_LINE][BUF_CHRS];

extern HMODULE hHmOutputPaneDLL;

extern PFNOUTPUT pOutputFunc;
extern PFNGETWINDOWHANDLE pOutputGetWindowFunc;