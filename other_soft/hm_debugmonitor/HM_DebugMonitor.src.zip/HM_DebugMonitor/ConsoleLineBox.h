#pragma once

#include <windows.h>
#include <richedit.h>

const int iConsoleLineHeight = 24;

extern HWND hConsoleLineEdit;

extern char hConsoleLineEditContent[4096]; // ���K�\���̈悩��e�L�X�g�𒊏o

HWND CreateConsoleLineBox(HWND hWnd, HINSTANCE hInst);
void DeleteConsoleLineBox();

BOOL SetInitialFont(HWND hWnd);

void MoveConsoleLineBox(HWND hWnd);

void SendHidemaruConsoleCommand(char *szCommand);
