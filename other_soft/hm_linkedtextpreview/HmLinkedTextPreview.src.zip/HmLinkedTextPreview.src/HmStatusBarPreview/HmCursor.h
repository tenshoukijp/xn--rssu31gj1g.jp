#pragma once


bool IsGlobalCursorIsHand();
