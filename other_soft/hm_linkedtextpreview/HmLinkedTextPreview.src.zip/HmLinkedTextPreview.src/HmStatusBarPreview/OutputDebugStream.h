#pragma once

extern void OutputDebugStream(const wchar_t *format, ...);
