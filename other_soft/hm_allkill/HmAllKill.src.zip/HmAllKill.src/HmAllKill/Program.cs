﻿using System;

namespace HmAllKill
{
    class Program
    {
        static void Main(string[] args)
        {
            //notepadのプロセスを取得
            System.Diagnostics.Process[] ps1 = System.Diagnostics.Process.GetProcessesByName("hidemaru");

            foreach (System.Diagnostics.Process p in ps1)
            {
                //プロセスを強制的に終了させる
                p.Kill();
            }

        }
    }
}
