﻿using System;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace CopyHideName
{
    class Program
    {
        [DllImport(@"C:\usr\hidemaru\HmSharedOutputPane.dll")]
        private extern static void SetSharedMessage(String msg);

        [STAThread]
        static void Main(string[] args)
        {
            if (args.Length == 0)
            {
                return;
            }

            var path = args[0];
            Clipboard.SetText(path);

            try
            {
                SetSharedMessage(path);
            }
            catch (Exception)
            {

            }
        }
    }
}
