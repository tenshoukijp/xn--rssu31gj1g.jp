﻿using System;
using System.Runtime.InteropServices;

using IronPython.Hosting;
using Microsoft.Scripting.Hosting;


// ★内部でdynamic型を利用しないもの。C++リンク用途のため「だけの」「コンパイルによってメソッド数が変化しない」インターフェイス。
// このようなスタブを用意することで、C++とリンクすることが可能となる(=メソッドの個数がC#とC++/CLIで一致させることが出来る)
public class IPyStaticLib
{
    public static void OutputDebugStream(String error)
    {
        hmPyDynamicLib.OutputDebugStream(error);
    }

    public static int CreateScope()
    {
        return hmPyDynamicLib.CreateScope();
    }

    public static int BindDllHandle(int dll)
    {
        return hmPyDynamicLib.BindDllHandle(dll);
    }

    public static void SetCodePage(int cp)
    {
        hmPyDynamicLib.SetCodePage(cp);
    }

    public static void SetModuleFullPath(String exe_full_path)
    {
        hmPyDynamicLib.SetModuleFullPath(exe_full_path);
    }

    public static int SetTmpVar(Object value)
    {
        return hmPyDynamicLib.SetTmpVar(value);
    }

    //-----------------------------------------------------------------
    public static int GetNumVar(String mng_var_name)
    {
        return hmPyDynamicLib.GetNumVar(mng_var_name);
    }

    public static int SetNumVar(String mng_var_name, int value)
    {
        return hmPyDynamicLib.SetNumVar(mng_var_name, value);
    }

    public static String GetStrVar(String mng_var_name)
    {
        return hmPyDynamicLib.GetStrVar(mng_var_name);
    }

    public static int SetStrVar(String mng_var_name, String value)
    {
        return hmPyDynamicLib.SetStrVar(mng_var_name, value);
    }
    //-----------------------------------------------------------------

    //-----------------------------------------------------------------
    public static int GetNumItemOfList(String mng_arr_name, int index)
    {
        return hmPyDynamicLib.GetNumItemOfList(mng_arr_name, index);
    }

    public static int SetNumItemOfList(String mng_arr_name, int index, int value)
    {
        return hmPyDynamicLib.SetNumItemOfList(mng_arr_name, index, value);
    }

    public static String GetStrItemOfList(String mng_arr_name, int index)
    {
        return hmPyDynamicLib.GetStrItemOfList(mng_arr_name, index);
    }

    public static int SetStrItemOfList(String mng_arr_name, int index, String value)
    {
        return hmPyDynamicLib.SetStrItemOfList(mng_arr_name, index, value);
    }
    //-----------------------------------------------------------------


    //-----------------------------------------------------------------
    public static int GetNumItemOfDict(String mng_arr_name, String key)
    {
        return hmPyDynamicLib.GetNumItemOfDict(mng_arr_name, key);
    }

    public static int SetNumItemOfDict(String mng_arr_name, String key, int value)
    {
        return hmPyDynamicLib.SetNumItemOfDict(mng_arr_name, key, value);
    }

    public static String GetStrItemOfDict(String mng_arr_name, String key)
    {
        return hmPyDynamicLib.GetStrItemOfDict(mng_arr_name, key);
    }

    public static int SetStrItemOfDict(String mng_arr_name, String key, String value)
    {
        return hmPyDynamicLib.SetStrItemOfDict(mng_arr_name, key, value);
    }
    //-----------------------------------------------------------------

    public static int DoString(string expression)
    {
        return hmPyDynamicLib.DoString(expression);
    }

    public static int DoFile(string filename)
    {
        return hmPyDynamicLib.DoFile(filename);
    }

    public static int DestroyScope()
    {
        return hmPyDynamicLib.DestroyScope();
    }

}


// ★クラス実装内のメソッドの中でdynamic型を利用したもの。これを直接利用しないのは、内部でdynamic型を利用していると、クラスに自動的にメソッドが追加されてしまい、C++とはヘッダのメソッドの個数が合わなくなりリンクできなくなるため。
public partial class hmPyDynamicLib
{
    public static ScriptEngine pe;
    public static ScriptScope ss;

    public static void OutputDebugStream(String error) {
        System.Diagnostics.Trace.WriteLine(error);
    }

    // hmのため
    //----------------------------------------------------------------------------------------------
    static Hidemaru hm;

    static readonly String strDllFullPath = System.Reflection.Assembly.GetExecutingAssembly().Location;

    // loadllした時の、変数の値。(そのマクロ内で何番めにloaddllしたかで値が変わる)
    static int iDllBindHandle = 0; // 1以上の整数。hmでloaddllした時の値
    public static int BindDllHandle(int dll)
    {
        iDllBindHandle = dll;
        return dll;
    }

    static String strExecuteFullpath;
    public static void SetModuleFullPath(String exe_full_path)
    {
        strExecuteFullpath = exe_full_path;
    }

    private static Object tmpVar = null;
    public static int SetTmpVar(Object value)
    {
        tmpVar = value;
        return 1;
    }

    //----------------------------------------------------------------------------------------------


    public static int CreateScope()
    {
        // まだエンジンが作られていなければ
        if (pe == null || ss == null)
        {
            try
            {
                //エンジン作成
                pe = Python.CreateEngine();
                ss = pe.CreateScope();
                hm = new Hidemaru();
                ss.SetVariable("hm", hm);
                return 1;
            }
            catch (Exception e)
            {
                OutputDebugStream(e.Message);
                return 0;
            }

        }
        return 1;
    }

    const int default_codepage = 932;
    static int codepage = default_codepage;
    public static void SetCodePage(int cp)
    {
        codepage = cp;
    }

    public static int GetNumVar(String mng_var_name)
    {
        if (CreateScope() == 0)
        {
            return 0;
        }

        try
        {
            Object var = ss.GetVariable(mng_var_name);
            return Convert.ToInt32(var); ;
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return 0;
    }

    public static int SetNumVar(String mng_var_name, int value)
    {
        if (CreateScope() == 0)
        {
            return 0;
        }

        try
        {
            ss.SetVariable(mng_var_name, value);
            return 1;
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return 0;
    }

    public static String GetStrVar(String mng_var_name)
    {
        if (CreateScope() == 0)
        {
            return "";
        }

        try
        {
            Object var = ss.GetVariable(mng_var_name);
            return var.ToString();
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return "";
    }

    public static int SetStrVar(String mng_var_name, String value)
    {
        if (CreateScope() == 0)
        {
            return 0;
        }

        try
        {
            ss.SetVariable(mng_var_name, value);
            return 1;
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return 0;
    }

    public static int GetNumItemOfList(String mng_arr_name, int index)
    {
        if (CreateScope() == 0)
        {
            return 0;
        }

        try
        {
            // 何型かはわからないが… 呼び出し側は list[x]形式で呼び出せるものだと考えた。
            dynamic arr = ss.GetVariable(mng_arr_name);
            // 要求に従い[ ]でアクセスしてみる。
            Object result = arr[index];

            // int型にできると信じるものである。
            return Convert.ToInt32(result);
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return 0;
    }

    public static int SetNumItemOfList(String mng_arr_name, int index, int value)
    {
        if (CreateScope() == 0)
        {
            return 0;
        }

        try
        {
            // 何型かはわからないが… 呼び出し側は list[x]形式で呼び出せるものだと考えた。
            dynamic arr = ss.GetVariable(mng_arr_name);
            // 要求に従い[ ]でアクセスした先に、値を入れてみる
            arr[index] = value;

            return 1;
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return 0;
    }

    public static String GetStrItemOfList(String mng_arr_name, int index)
    {
        if (CreateScope() == 0)
        {
            return "";
        }

        try
        {
            // 何型かはわからないが… 呼び出し側は list[x]形式で呼び出せるものだと考えた。
            dynamic arr = ss.GetVariable(mng_arr_name);

            // 要求に従い[ ]でアクセスしてみる。
            Object result = arr[index];

            // int型にできると信じるものである。
            return Convert.ToString(result);
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return "";
    }

    public static int SetStrItemOfList(String mng_arr_name, int index, String value)
    {
        if (CreateScope() == 0)
        {
            return 0;
        }

        try
        {
            // 何型かはわからないが… 呼び出し側は list[x]形式で呼び出せるものだと考えた。
            dynamic arr = ss.GetVariable(mng_arr_name);
            // 要求に従い[ ]でアクセスした先に、値を入れてみる
            arr[index] = value;

            return 1;
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return 0;
    }

    public static int GetNumItemOfDict(String mng_arr_name, String key)
    {
        if (CreateScope() == 0)
        {
            return 0;
        }

        try
        {
            // 何型かはわからないが… 呼び出し側は list[x]形式で呼び出せるものだと考えた。
            dynamic arr = ss.GetVariable(mng_arr_name);
            // 要求に従い[ ]でアクセスしてみる。
            Object result = arr[key];
            // int型にできると信じるものである。
            return Convert.ToInt32(result);
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return 0;
    }

    public static int SetNumItemOfDict(String mng_arr_name, String key, int value)
    {
        if (CreateScope() == 0)
        {
            return 0;
        }

        try
        {
            // 何型かはわからないが… 呼び出し側は list[x]形式で呼び出せるものだと考えた。
            dynamic arr = ss.GetVariable(mng_arr_name);
            // 要求に従い[ ]でアクセスした先に、値を入れてみる
            arr[key] = value;

            return 1;
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return 0;
    }

    public static String GetStrItemOfDict(String mng_arr_name, String key)
    {
        if (CreateScope() == 0)
        {
            return "";
        }

        try
        {
            // 何型かはわからないが… 呼び出し側は list[x]形式で呼び出せるものだと考えた。
            dynamic arr = ss.GetVariable(mng_arr_name);

            // 要求に従い[ ]でアクセスしてみる。
            Object result = arr[key];

            // int型にできると信じるものである。
            return Convert.ToString(result);
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return "";
    }
    public static int SetStrItemOfDict(String mng_arr_name, String key, String value)
    {
        if (CreateScope() == 0)
        {
            return 0;
        }

        try
        {
            // 何型かはわからないが… 呼び出し側は list[x]形式で呼び出せるものだと考えた。
            dynamic arr = ss.GetVariable(mng_arr_name);
            // 要求に従い[ ]でアクセスした先に、値を入れてみる
            arr[key] = value;

            return 1;
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return 0;
    }


    public static int DoString(String expression)
    {
        if (CreateScope() == 0)
        {
            return 0;
        }

        try
        {
            pe.Execute(expression, ss);
            return 1;
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return 0;
    }

    public static int DoFile(String filename)
    {
        if (CreateScope() == 0)
        {
            return 0;
        }

        try
        {
            using (System.IO.StreamReader sr = new System.IO.StreamReader(filename, System.Text.Encoding.GetEncoding(codepage)))
            {
                String expression = sr.ReadToEnd();
                sr.Close();
                return DoString(expression);
            }
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return 0;
    }

    public static int DestroyScope()
    {
        if (ss != null)
        {
            // FreeLibrary直前の関数の呼び出し。
            try
            {
                // pe.Execute("if DestroyScope: DestroyScope()", ss);

                dynamic fnDllEnsureDetach = ss.GetVariable("DestroyScope");
                if (fnDllEnsureDetach != null)
                {
                    fnDllEnsureDetach();
                }
            }
            catch (Exception)
            {
            }
            ss = null;
            pe = null;
        }

        SetCodePage(default_codepage);
        iDllBindHandle = 0;
        tmpVar = null;
 
        return 0;
    }

}

