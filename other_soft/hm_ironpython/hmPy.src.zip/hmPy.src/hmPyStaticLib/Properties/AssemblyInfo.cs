﻿using System.Reflection;
using System.Runtime.InteropServices;


[assembly: ComVisible(false)]

// 次の GUID は、このプロジェクトが COM に公開される場合の、typelib の ID です
[assembly: Guid("5d16c56b-9442-48a0-bcb7-86f7fa32f698")]

[assembly: AssemblyVersion("1.4.0.8")]
[assembly: AssemblyFileVersion("1.4.0.8")]
