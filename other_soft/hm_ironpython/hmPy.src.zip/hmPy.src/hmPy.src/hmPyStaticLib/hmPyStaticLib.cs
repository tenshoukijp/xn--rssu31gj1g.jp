﻿using System;
using System.Runtime.InteropServices;

using IronPython.Hosting;
using Microsoft.Scripting.Hosting;


// ★内部でdynamic型を利用しないもの。C++リンク用途のため「だけの」「コンパイルによってメソッド数が変化しない」インターフェイス。
// このようなスタブを用意することで、C++とリンクすることが可能となる(=メソッドの個数がC#とC++/CLIで一致させることが出来る)
public class IPyStaticLib
{
    public static void OutputDebugStream(String error)
    {
        hmPyDynamicLib.OutputDebugStream(error);
    }

    public static int CreateScope()
    {
        return hmPyDynamicLib.CreateScope();
    }

    public static void SetCodePage(int cp)
    {
        hmPyDynamicLib.SetCodePage(cp);
    }

    public static void SetModuleFullPath(String exe_full_path)
    {
        hmPyDynamicLib.SetModuleFullPath(exe_full_path);
    }

    //-----------------------------------------------------------------
    public static int GetNumVar(String mng_var_name)
    {
        return hmPyDynamicLib.GetNumVar(mng_var_name);
    }

    public static int SetNumVar(String mng_var_name, int value)
    {
        return hmPyDynamicLib.SetNumVar(mng_var_name, value);
    }

    public static String GetStrVar(String mng_var_name)
    {
        return hmPyDynamicLib.GetStrVar(mng_var_name);
    }

    public static int SetStrVar(String mng_var_name, String value)
    {
        return hmPyDynamicLib.SetStrVar(mng_var_name, value);
    }
    //-----------------------------------------------------------------

    //-----------------------------------------------------------------
    public static int GetNumItemOfList(String mng_arr_name, int index)
    {
        return hmPyDynamicLib.GetNumItemOfList(mng_arr_name, index);
    }

    public static int SetNumItemOfList(String mng_arr_name, int index, int value)
    {
        return hmPyDynamicLib.SetNumItemOfList(mng_arr_name, index, value);
    }

    public static String GetStrItemOfList(String mng_arr_name, int index)
    {
        return hmPyDynamicLib.GetStrItemOfList(mng_arr_name, index);
    }

    public static int SetStrItemOfList(String mng_arr_name, int index, String value)
    {
        return hmPyDynamicLib.SetStrItemOfList(mng_arr_name, index, value);
    }
    //-----------------------------------------------------------------


    //-----------------------------------------------------------------
    public static int GetNumItemOfDict(String mng_arr_name, String key)
    {
        return hmPyDynamicLib.GetNumItemOfDict(mng_arr_name, key);
    }

    public static int SetNumItemOfDict(String mng_arr_name, String key, int value)
    {
        return hmPyDynamicLib.SetNumItemOfDict(mng_arr_name, key, value);
    }

    public static String GetStrItemOfDict(String mng_arr_name, String key)
    {
        return hmPyDynamicLib.GetStrItemOfDict(mng_arr_name, key);
    }

    public static int SetStrItemOfDict(String mng_arr_name, String key, String value)
    {
        return hmPyDynamicLib.SetStrItemOfDict(mng_arr_name, key, value);
    }
    //-----------------------------------------------------------------

    public static int DoString(string expression)
    {
        return hmPyDynamicLib.DoString(expression);
    }

    public static int DoFile(string filename)
    {
        return hmPyDynamicLib.DoFile(filename);
    }

}

// アンマネージドライブラリの遅延での読み込み。C++のLoadLibraryと同じことをするため
// これをする理由は、このhmPyとHideamru.exeが異なるディレクトリに存在する可能性があるため、
// C#風のDllImportは成立しないからだ。
internal class UnManagedDll : IDisposable
{
    [DllImport("kernel32")]
    static extern IntPtr LoadLibrary(string lpFileName);
    [DllImport("kernel32")]
    static extern IntPtr GetProcAddress(IntPtr hModule, string lpProcName);
    [DllImport("kernel32")]
    static extern bool FreeLibrary(IntPtr hModule);

    IntPtr moduleHandle;

    public UnManagedDll(string lpFileName)
    {
        moduleHandle = LoadLibrary(lpFileName);
    }

    public IntPtr ModuleHandle
    {
        get
        {
            return moduleHandle;
        }
    }

    public T GetProcDelegate<T>(string method) where T : class
    {
        IntPtr methodHandle = GetProcAddress(moduleHandle, method);
        T r = Marshal.GetDelegateForFunctionPointer(methodHandle, typeof(T)) as T;
        return r;
    }

    public void Dispose()
    {
        FreeLibrary(moduleHandle);
    }
}


// ★クラス実装内のメソッドの中でdynamic型を利用したもの。これを直接利用しないのは、内部でdynamic型を利用していると、クラスに自動的にメソッドが追加されてしまい、C++とはヘッダのメソッドの個数が合わなくなりリンクできなくなるため。
public class hmPyDynamicLib
{
    public static ScriptEngine pe;
    public static ScriptScope ss;

    [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
    public static extern void OutputDebugString(String message);

    public static void OutputDebugStream(String error) {
        OutputDebugString(error + "\n");
    }

    static String strExecuteFullpath;
    public static void SetModuleFullPath(String exe_full_path)
    {
        strExecuteFullpath = exe_full_path;
    }

    public class Hidemaru
    {
        delegate IntPtr TGetTotalTextUnicode();
        delegate IntPtr TGetLineTextUnicode(int nLineNo);
        delegate int TGetCursorPosUnicode(ref int pnLineNo, ref int pnColumn);
        delegate int TCheckQueueStatus();

        static TGetTotalTextUnicode pGetTotalTextUnicode;
        static TGetLineTextUnicode pGetLineTextUnicode;
        static TGetCursorPosUnicode pGetCursorPosUnicode;
        static TCheckQueueStatus pCheckQueueStatus;

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr GlobalLock(IntPtr hMem);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern int GlobalUnlock(IntPtr hMem);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr GlobalFree(IntPtr hMem);

        public static void debuginfo(Object expression)
        {
            OutputDebugString(expression.ToString() + "\n");
        }

        // 秀丸本体のexeを指すモジュールハンドル
        static UnManagedDll hmExeHandle;

        // バージョン。hm.versionのため。読み取り専用
        static double _ver;
        public static double version
        {
            get { return _ver; }
        }

        // 秀丸本体のExport関数を使えるようにポインタ設定。
        static void SetUnManagedDll()
        {
            // 初めての代入のみ
            if (hmExeHandle == null)
            {
                hmExeHandle = new UnManagedDll(strExecuteFullpath);

                System.Diagnostics.FileVersionInfo vi = System.Diagnostics.FileVersionInfo.GetVersionInfo(strExecuteFullpath);
                _ver = 100 * vi.FileMajorPart + 10 * vi.FileMinorPart + 1 * vi.FileBuildPart + 0.01 * vi.FilePrivatePart;

                OutputDebugStream(version.ToString());
                if (version >= 866) // ver 8.6.6以上が対象
                {
                    pGetTotalTextUnicode = hmExeHandle.GetProcDelegate<TGetTotalTextUnicode>("Hidemaru_GetTotalTextUnicode");
                    pGetLineTextUnicode = hmExeHandle.GetProcDelegate<TGetLineTextUnicode>("Hidemaru_GetLineTextUnicode");
                    pGetCursorPosUnicode = hmExeHandle.GetProcDelegate<TGetCursorPosUnicode>("Hidemaru_GetCursorPosUnicode");
                    pCheckQueueStatus = hmExeHandle.GetProcDelegate<TCheckQueueStatus>("Hidemaru_CheckQueueStatus");
                }
            }
        }

        // 座標型。Point型では、System.Drawingを読み込まないとダメなので負荷がある。また、x, yは秀丸に別値として存在するので、
        // あくまでも、マクロのcolumnとlinenoと一致しているという主張。なお、x, yはワープロ的な座標を拾ってくる。
        // columnやlinenoはエディタ的な座標である。
        public struct HmPoint
        {
            private int m_lineno;
            private int m_column;
            public HmPoint(int lineno, int column)
            {
                this.m_lineno = lineno;
                this.m_column = column;
            }
            public int column { get { return m_column; } }
            public int lineno { get { return m_lineno; } }
        }

        // columnやlinenoはエディタ的な座標である。
        public static HmPoint GetCursorPos()
        {
            SetUnManagedDll();

            if (version < 866) {
                OutputDebugStream("このメソッドは秀丸エディタ v8.66以降で利用可能です。");
                return new HmPoint(1, 0);
            }

            int column = -1;
            int lineno = -1;
            pGetCursorPosUnicode(ref lineno, ref column);
            HmPoint p = new HmPoint(lineno, column);
            return p;
        }

        // 途中でエラーが出るかもしれないので、相応しいUnlockやFreeが出来るように内部管理用
        private enum HGlobalStatus { None, Lock, Unlock, Free };

        // 現在の秀丸の編集中のテキスト全て。元が何の文字コードでも関係なく秀丸がwchar_tのユニコードで返してくれるので、
        // String^型に入れておけば良い。
        public static String GetTotalText()
        {
            SetUnManagedDll();

            if (version < 866) {
                OutputDebugStream("このメソッドは秀丸エディタ v8.66以降で利用可能です。");
                return "";
            }

            String curstr = "";
            IntPtr hGlobal = pGetTotalTextUnicode();
            HGlobalStatus hgs = HGlobalStatus.None;
            if (hGlobal != null)
            {
                try { 
                    IntPtr ret = GlobalLock(hGlobal);
                    hgs = HGlobalStatus.Lock;
                    curstr = Marshal.PtrToStringUni(ret);
                    GlobalUnlock(hGlobal);
                    hgs = HGlobalStatus.Unlock;
                    GlobalFree(hGlobal);
                    hgs = HGlobalStatus.Free;
                }
                catch (Exception e)
                {
                    OutputDebugStream(e.Message);
                }
                finally
                {
                    switch (hgs) {
                        // ロックだけ成功した
                        case HGlobalStatus.Lock: {
                            GlobalUnlock(hGlobal);
                            GlobalFree(hGlobal);
                            break;
                        }
                        // アンロックまで成功した
                        case HGlobalStatus.Unlock: {
                            GlobalFree(hGlobal);
                            break;
                        }
                        // フリーまで成功した
                        case HGlobalStatus.Free: {
                            break;
                        }
                    }
                }
            }
            return curstr;
        }

        // 現在の秀丸の編集中のテキストで、カーソルがある行だけのテキスト。
        // 元が何の文字コードでも関係なく秀丸がwchar_tのユニコードで返してくれるので、
        // String^型に入れておけば良い。
        public static String GetLineText()
        {
            SetUnManagedDll();

            if (version < 866) {
                OutputDebugStream("このメソッドは秀丸エディタ v8.66以降で利用可能です。");
                return "";
            }

            HmPoint p = GetCursorPos();

            String curstr = "";
            IntPtr hGlobal = pGetLineTextUnicode(p.lineno);
            HGlobalStatus hgs = HGlobalStatus.None;
            if (hGlobal != null)
            {
                try
                {
                    IntPtr ret = GlobalLock(hGlobal);
                    hgs = HGlobalStatus.Lock;
                    curstr = Marshal.PtrToStringUni(ret);
                    GlobalUnlock(hGlobal);
                    hgs = HGlobalStatus.Unlock;
                    GlobalFree(hGlobal);
                    hgs = HGlobalStatus.Free;
                }
                catch (Exception e)
                {
                    OutputDebugStream(e.Message);
                }
                finally
                {
                    switch (hgs)
                    {
                        // ロックだけ成功した
                        case HGlobalStatus.Lock:
                            {
                                GlobalUnlock(hGlobal);
                                GlobalFree(hGlobal);
                                break;
                            }
                        // アンロックまで成功した
                        case HGlobalStatus.Unlock:
                            {
                                GlobalFree(hGlobal);
                                break;
                            }
                        // フリーまで成功した
                        case HGlobalStatus.Free:
                            {
                                break;
                            }
                    }
                }
            }
            return curstr;
        }
    }

    static Hidemaru hm;
    public static int CreateScope()
    {
        // まだエンジンが作られていなければ
        if (pe == null || ss == null)
        {
            try
            {
                //エンジン作成
                pe = Python.CreateEngine();
                ss = pe.CreateScope();
                hm = new Hidemaru();
                ss.SetVariable("hm", hm);
                return 1;
            }
            catch (Exception e)
            {
                OutputDebugStream(e.Message);
                return 0;
            }

        }
        return 1;
    }

    static int codepage = 932;
    public static void SetCodePage(int cp)
    {
        codepage = cp;
    }

    public static int GetNumVar(String mng_var_name)
    {
        if (CreateScope() == 0)
        {
            return 0;
        }

        try
        {
            Object var = ss.GetVariable(mng_var_name);
            return Convert.ToInt32(var); ;
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return 0;
    }

    public static int SetNumVar(String mng_var_name, int value)
    {
        if (CreateScope() == 0)
        {
            return 0;
        }

        try
        {
            ss.SetVariable(mng_var_name, value);
            int a = ss.GetVariable(mng_var_name);
            return 1;
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return 0;
    }

    public static String GetStrVar(String mng_var_name)
    {
        if (CreateScope() == 0)
        {
            return "";
        }

        try
        {
            Object var = ss.GetVariable(mng_var_name);
            return var.ToString();
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return "";
    }

    public static int SetStrVar(String mng_var_name, String value)
    {
        if (CreateScope() == 0)
        {
            return 0;
        }

        try
        {
            ss.SetVariable(mng_var_name, value);
            return 1;
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return 0;
    }

    public static int GetNumItemOfList(String mng_arr_name, int index)
    {
        if (CreateScope() == 0)
        {
            return 0;
        }

        try
        {
            // 何型かはわからないが… 呼び出し側は list[x]形式で呼び出せるものだと考えた。
            dynamic arr = ss.GetVariable(mng_arr_name);
            // 要求に従い[ ]でアクセスしてみる。
            Object result = arr[index];

            // int型にできると信じるものである。
            return Convert.ToInt32(result);
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return 0;
    }

    public static int SetNumItemOfList(String mng_arr_name, int index, int value)
    {
        if (CreateScope() == 0)
        {
            return 0;
        }

        try
        {
            // 何型かはわからないが… 呼び出し側は list[x]形式で呼び出せるものだと考えた。
            dynamic arr = ss.GetVariable(mng_arr_name);
            // 要求に従い[ ]でアクセスした先に、値を入れてみる
            arr[index] = value;

            return 1;
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return 0;
    }

    public static String GetStrItemOfList(String mng_arr_name, int index)
    {
        if (CreateScope() == 0)
        {
            return "";
        }

        try
        {
            // 何型かはわからないが… 呼び出し側は list[x]形式で呼び出せるものだと考えた。
            dynamic arr = ss.GetVariable(mng_arr_name);

            // 要求に従い[ ]でアクセスしてみる。
            Object result = arr[index];

            // int型にできると信じるものである。
            return Convert.ToString(result);
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return "";
    }

    public static int SetStrItemOfList(String mng_arr_name, int index, String value)
    {
        if (CreateScope() == 0)
        {
            return 0;
        }

        try
        {
            // 何型かはわからないが… 呼び出し側は list[x]形式で呼び出せるものだと考えた。
            dynamic arr = ss.GetVariable(mng_arr_name);
            // 要求に従い[ ]でアクセスした先に、値を入れてみる
            arr[index] = value;

            return 1;
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return 0;
    }

    public static int GetNumItemOfDict(String mng_arr_name, String key)
    {
        if (CreateScope() == 0)
        {
            return 0;
        }

        try
        {
            // 何型かはわからないが… 呼び出し側は list[x]形式で呼び出せるものだと考えた。
            dynamic arr = ss.GetVariable(mng_arr_name);
            // 要求に従い[ ]でアクセスしてみる。
            Object result = arr[key];
            // int型にできると信じるものである。
            return Convert.ToInt32(result);
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return 0;
    }

    public static int SetNumItemOfDict(String mng_arr_name, String key, int value)
    {
        if (CreateScope() == 0)
        {
            return 0;
        }

        try
        {
            // 何型かはわからないが… 呼び出し側は list[x]形式で呼び出せるものだと考えた。
            dynamic arr = ss.GetVariable(mng_arr_name);
            // 要求に従い[ ]でアクセスした先に、値を入れてみる
            arr[key] = value;

            return 1;
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return 0;
    }

    public static String GetStrItemOfDict(String mng_arr_name, String key)
    {
        if (CreateScope() == 0)
        {
            return "";
        }

        try
        {
            // 何型かはわからないが… 呼び出し側は list[x]形式で呼び出せるものだと考えた。
            dynamic arr = ss.GetVariable(mng_arr_name);

            // 要求に従い[ ]でアクセスしてみる。
            Object result = arr[key];

            // int型にできると信じるものである。
            return Convert.ToString(result);
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return "";
    }
    public static int SetStrItemOfDict(String mng_arr_name, String key, String value)
    {
        if (CreateScope() == 0)
        {
            return 0;
        }

        try
        {
            // 何型かはわからないが… 呼び出し側は list[x]形式で呼び出せるものだと考えた。
            dynamic arr = ss.GetVariable(mng_arr_name);
            // 要求に従い[ ]でアクセスした先に、値を入れてみる
            arr[key] = value;

            return 1;
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return 0;
    }


    public static int DoString(String expression)
    {
        if (CreateScope() == 0)
        {
            return 0;
        }

        try
        {
            pe.Execute(expression, ss);
            return 1;
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return 0;
    }

    public static int DoFile(String filename)
    {
        if (CreateScope() == 0)
        {
            return 0;
        }

        try
        {
            using (System.IO.StreamReader sr = new System.IO.StreamReader(filename, System.Text.Encoding.GetEncoding(codepage)))
            {
                String expression = sr.ReadToEnd();
                sr.Close();
                return DoString(expression);
            }
        }
        catch (Exception e)
        {
            OutputDebugStream(e.Message);
        }
        return 0;
    }

}

