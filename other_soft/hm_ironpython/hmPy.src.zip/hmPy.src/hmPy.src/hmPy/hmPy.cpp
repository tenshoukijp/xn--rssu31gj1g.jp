#include <windows.h>
#include <string>
#include <map>

#include "outputdebugstream.h"
#include "string_converter.h"
#include "hmPyStatlcLib.h"

#define MACRO_DLL extern "C" __declspec(dllexport)

using namespace std;
using namespace System;

TCHAR szHidemaruFullPath[MAX_PATH * 2] = _T("");
bool isSetModuleFullPath = false;
void SetModuleFullPath() {
	if (!isSetModuleFullPath) {
		GetModuleFileName(NULL, szHidemaruFullPath, sizeof(szHidemaruFullPath));
		IPyStaticLib::SetModuleFullPath(gcnew String(szHidemaruFullPath));
		isSetModuleFullPath = true;
	}
}

//------------------------------------------------------------------------------------
MACRO_DLL int GetNumVar(const TCHAR *sz_var_name) {
	SetModuleFullPath();
	return IPyStaticLib::GetNumVar(gcnew String(sz_var_name));
}

MACRO_DLL int SetNumVar(const TCHAR *sz_var_name, int value) {
	SetModuleFullPath();
	return IPyStaticLib::SetNumVar(gcnew String(sz_var_name), value);
}

// �G�ۂ̃L���b�V���̂���
tstring strvars;
MACRO_DLL const TCHAR * GetStrVar(const TCHAR *sz_var_name) {
	SetModuleFullPath();
	auto var = IPyStaticLib::GetStrVar(gcnew String(sz_var_name));
	strvars = String_to_string(var->ToString());
	return strvars.data();
}

MACRO_DLL int SetStrVar(const TCHAR *sz_var_name, const TCHAR *value) {
	SetModuleFullPath();
	return IPyStaticLib::SetStrVar(gcnew String(sz_var_name), gcnew String(value));
}
//------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------
MACRO_DLL int GetNumItemOfList(const TCHAR *sz_arr_name, const int index) {
	SetModuleFullPath();
	return IPyStaticLib::GetNumItemOfList(gcnew String(sz_arr_name), index);
}

MACRO_DLL int SetNumItemOfList(const TCHAR *sz_arr_name, const int index, const int value) {
	SetModuleFullPath();
	return IPyStaticLib::SetNumItemOfList(gcnew String(sz_arr_name), index, value);
}

// �G�ۂ̃L���b�V���̂���
tstring strvarsoflist;
MACRO_DLL const TCHAR * GetStrItemOfList(const TCHAR *sz_arr_name, const int index) {
	SetModuleFullPath();
	auto var = IPyStaticLib::GetStrItemOfList(gcnew String(sz_arr_name), index);
	strvarsoflist = String_to_string(var->ToString());
	return strvarsoflist.data();
}

MACRO_DLL int SetStrItemOfList(const TCHAR *sz_arr_name, const int index, const TCHAR* value) {
	SetModuleFullPath();
	return IPyStaticLib::SetStrItemOfList(gcnew String(sz_arr_name), index, gcnew String(value));
}
//------------------------------------------------------------------------------------



//------------------------------------------------------------------------------------
MACRO_DLL int GetNumItemOfDict(const TCHAR *sz_arr_name, const TCHAR *key) {
	SetModuleFullPath();
	return IPyStaticLib::GetNumItemOfDict(gcnew String(sz_arr_name), gcnew String(key));
}

MACRO_DLL int SetNumItemOfDict(const TCHAR *sz_arr_name, const TCHAR *key, const int value) {
	SetModuleFullPath();
	return IPyStaticLib::SetNumItemOfDict(gcnew String(sz_arr_name), gcnew String(key), value);
}

// �G�ۂ̃L���b�V���̂���
tstring strvarsofdict;
MACRO_DLL const TCHAR * GetStrItemOfDict(const TCHAR *sz_arr_name, const TCHAR *key) {
	SetModuleFullPath();
	auto var = IPyStaticLib::GetStrItemOfDict(gcnew String(sz_arr_name), gcnew String(key));
	strvarsofdict = String_to_string(var->ToString());
	return strvarsofdict.data();
}

MACRO_DLL int SetStrItemOfDict(const TCHAR *sz_arr_name, const TCHAR *key, const TCHAR* value) {
	SetModuleFullPath();
	return IPyStaticLib::SetStrItemOfDict(gcnew String(sz_arr_name), gcnew String(key), gcnew String(value));
}
//------------------------------------------------------------------------------------


MACRO_DLL int DoString(TCHAR *szexpression) {
	SetModuleFullPath();
	return IPyStaticLib::DoString(gcnew String(szexpression));
}

MACRO_DLL int DoFile(TCHAR *szfilename) {
	SetModuleFullPath();
	return IPyStaticLib::DoFile(gcnew String(szfilename));
}
