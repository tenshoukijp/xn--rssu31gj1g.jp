#pragma once;

using namespace System;

extern void OutputDebugStream(String^ message);