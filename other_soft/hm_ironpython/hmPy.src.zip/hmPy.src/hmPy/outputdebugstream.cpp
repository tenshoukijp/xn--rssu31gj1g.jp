#include <windows.h>
#include <string>

using namespace System;

extern std::string String_to_string(System::String^ str);

void OutputDebugStream(String^ message) {
	std::string std_message = String_to_string(message);
	OutputDebugString(std_message.data());
}