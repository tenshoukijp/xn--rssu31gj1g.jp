#include <windows.h>
#include <string>
#include <map>

#include "outputdebugstream.h"
#include "string_converter.h"
#include "hmPyStatlcLib.h"

#define MACRO_DLL extern "C" __declspec(dllexport)

using namespace std;
using namespace System;

TCHAR szHidemaruFullPath[MAX_PATH] = _T("");
bool isSetModuleFullPath = false;
void SetModuleFullPath() {
	if (!isSetModuleFullPath) {
		GetModuleFileName(NULL, szHidemaruFullPath, sizeof(szHidemaruFullPath));
		IPyStaticLib::SetModuleFullPath(gcnew String(szHidemaruFullPath));
		isSetModuleFullPath = true;
	}
}

static int codepage = 932;
MACRO_DLL int SetCodePage(int cp) {
	codepage = cp;
	SetModuleFullPath();
	IPyStaticLib::SetCodePage(cp);
	return TRUE;
}

//------------------------------------------------------------------------------------
MACRO_DLL int GetNumVar(const void *sz_var_name) {
	SetModuleFullPath();
	if (codepage == 932) {
		return IPyStaticLib::GetNumVar(gcnew String((char *)sz_var_name));
	}
	else {
		return IPyStaticLib::GetNumVar(gcnew String((wchar_t *)sz_var_name));
	}
}

MACRO_DLL int SetNumVar(const void *sz_var_name, int value) {
	SetModuleFullPath();
	if (codepage == 932) {
		return IPyStaticLib::SetNumVar(gcnew String((char *)sz_var_name), value);
	}
	else {
		return IPyStaticLib::SetNumVar(gcnew String((wchar_t *)sz_var_name), value);
	}
}

// �G�ۂ̃L���b�V���̂���
MACRO_DLL const void * GetStrVar(const void *sz_var_name) {
	SetModuleFullPath();
	if (codepage == 932) {
		auto var = IPyStaticLib::GetStrVar(gcnew String((char *)sz_var_name));
		static string strvars = String_to_string(var->ToString());
		return strvars.data();
	}
	else {
		auto var = IPyStaticLib::GetStrVar(gcnew String((wchar_t *)sz_var_name));
		static wstring strvars = String_to_wstring(var->ToString());
		return strvars.data();
	}
}

MACRO_DLL int SetStrVar(const void *sz_var_name, const void *value) {
	SetModuleFullPath();
	if (codepage == 932) {
		return IPyStaticLib::SetStrVar(gcnew String((char *)sz_var_name), gcnew String((char *)value));
	}
	else {
		return IPyStaticLib::SetStrVar(gcnew String((wchar_t *)sz_var_name), gcnew String((wchar_t *)value));
	}
}
//------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------
MACRO_DLL int GetNumItemOfList(const void *sz_arr_name, const int index) {
	SetModuleFullPath();
	if (codepage == 932) {
		return IPyStaticLib::GetNumItemOfList(gcnew String((char *)sz_arr_name), index);
	}
	else {
		return IPyStaticLib::GetNumItemOfList(gcnew String((wchar_t *)sz_arr_name), index);
	}
}

MACRO_DLL int SetNumItemOfList(const void *sz_arr_name, const int index, const int value) {
	SetModuleFullPath();
	if (codepage == 932) {
		return IPyStaticLib::SetNumItemOfList(gcnew String((char *)sz_arr_name), index, value);
	}
	else {
		return IPyStaticLib::SetNumItemOfList(gcnew String((wchar_t *)sz_arr_name), index, value);
	}
}

// �G�ۂ̃L���b�V���̂���
MACRO_DLL const void * GetStrItemOfList(const void *sz_arr_name, const int index) {
	SetModuleFullPath();
	if (codepage == 932) {
		auto var = IPyStaticLib::GetStrItemOfList(gcnew String((char *)sz_arr_name), index);
		static string strvarsoflist = String_to_string(var->ToString());
		return strvarsoflist.data();
	}
	else {
		auto var = IPyStaticLib::GetStrItemOfList(gcnew String((wchar_t *)sz_arr_name), index);
		static wstring strvarsoflist = String_to_wstring(var->ToString());
		return strvarsoflist.data();
	}
}

MACRO_DLL int SetStrItemOfList(const void *sz_arr_name, const int index, const void* value) {
	SetModuleFullPath();
	if (codepage == 932) {
		return IPyStaticLib::SetStrItemOfList(gcnew String((char *)sz_arr_name), index, gcnew String((char *)value));
	}
	else {
		return IPyStaticLib::SetStrItemOfList(gcnew String((wchar_t *)sz_arr_name), index, gcnew String((wchar_t *)value));
	}
}
//------------------------------------------------------------------------------------



//------------------------------------------------------------------------------------
MACRO_DLL int GetNumItemOfDict(const void *sz_arr_name, const void *key) {
	SetModuleFullPath();
	if (codepage == 932) {
		return IPyStaticLib::GetNumItemOfDict(gcnew String((char *)sz_arr_name), gcnew String((char *)key));
	}
	else {
		return IPyStaticLib::GetNumItemOfDict(gcnew String((wchar_t *)sz_arr_name), gcnew String((wchar_t *)key));
	}
}

MACRO_DLL int SetNumItemOfDict(const void *sz_arr_name, const void *key, const int value) {
	SetModuleFullPath();
	if (codepage == 932) {
		return IPyStaticLib::SetNumItemOfDict(gcnew String((char *)sz_arr_name), gcnew String((char *)key), value);
	}
	else {
		return IPyStaticLib::SetNumItemOfDict(gcnew String((wchar_t *)sz_arr_name), gcnew String((wchar_t *)key), value);
	}
}

// �G�ۂ̃L���b�V���̂���

MACRO_DLL const void * GetStrItemOfDict(const void *sz_arr_name, const void *key) {
	SetModuleFullPath();
	if (codepage == 932) {
		auto var = IPyStaticLib::GetStrItemOfDict(gcnew String((char *)sz_arr_name), gcnew String((char *)key));
		static string strvarsofdict = String_to_string(var->ToString());
		return strvarsofdict.data();
	}
	else {
		auto var = IPyStaticLib::GetStrItemOfDict(gcnew String((wchar_t *)sz_arr_name), gcnew String((wchar_t *)key));
		static wstring strvarsofdict = String_to_wstring(var->ToString());
		return strvarsofdict.data();

	}
}

MACRO_DLL int SetStrItemOfDict(const void *sz_arr_name, const void *key, const void* value) {
	SetModuleFullPath();
	if (codepage == 932) {
		return IPyStaticLib::SetStrItemOfDict(gcnew String((char *)sz_arr_name), gcnew String((char *)key), gcnew String((char *)value));
	}
	else {
		return IPyStaticLib::SetStrItemOfDict(gcnew String((wchar_t *)sz_arr_name), gcnew String((wchar_t *)key), gcnew String((wchar_t *)value));

	}
}
//------------------------------------------------------------------------------------


MACRO_DLL int DoString(const void *szexpression) {
	SetModuleFullPath();
	if (codepage == 932) {
		return IPyStaticLib::DoString(gcnew String((char *)szexpression));
	}
	else {
		return IPyStaticLib::DoString(gcnew String((wchar_t *)szexpression));
	}
}

MACRO_DLL int DoFile(const void *szfilename) {
	SetModuleFullPath();
	if (codepage == 932) {
		return IPyStaticLib::DoFile(gcnew String((char *)szfilename));
	}
	else {
		return IPyStaticLib::DoFile(gcnew String((wchar_t *)szfilename));
	}
}
