#include <string>

System::String^ string_to_String(std::string str);
std::string String_to_string(System::String^ str);