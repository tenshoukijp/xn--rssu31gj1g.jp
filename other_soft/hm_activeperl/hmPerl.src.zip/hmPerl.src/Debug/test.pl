﻿
sub Hm {
    my ($class) = @_;
    return bless {}, $class;
}

sub Edit {
    my ($class) = @_;
	return $class;
}

sub Eval {
    my ($self, $expression) = @_;
	$hm_Macro_Eval = $expression;
    return $cmd;
}

sub Macro {
    my ($class) = @_;
	return $class;
}

sub Var {
    my ($self, $simbol, $value) = @_;
	$hm_Macro_Var_Simbol = $simbol;
	if (undef($value)) {
		return $hm_Macro_Var_Value;
	} else {
		$hm_Macro_Var_Value = $simbol;
		return $hm_Macro_Var_Value;
	}
}
