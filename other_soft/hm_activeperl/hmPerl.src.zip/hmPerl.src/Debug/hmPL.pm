﻿sub ezsub {
	return "555";
}

#--------------------------------------------------------------
# 秀丸の各種変数の読み取りや書き込みを行う
#--------------------------------------------------------------
sub Hm {
    my ($class) = @_;
    return bless {}, $class;
}
#--------------------------------------------------------------

	# 編集中の秀丸のテキストを得たり、テキストを変更したりする
    #--------------------------------------------------------------
	sub Edit {
	    my ($class) = @_;
		return $class;
	}

	    #--------------------------------------------------------------
		sub TotalText {
		    my ($self, $value) = @_;
			if ($#_ == 0) {
				return $hm_Edit_TotalText;
			} else {
				return $hm_Edit_TotalText = $value;
			}
		}

		sub SelectedText {
		    my ($self, $value) = @_;
			if ($#_ == 0) {
				return $hm_Edit_SelectedText;
			} else {
				return $hm_Edit_SelectedText = $value;
			}
		}

		sub LineText {
		    my ($self, $value) = @_;
			if ($#_ == 0) {
				return $hm_Edit_LineText;
			} else {
				return $hm_Edit_Line = $value;
			}
		}
	    #--------------------------------------------------------------

    #--------------------------------------------------------------



	# 秀丸マクロをPerl内から実行したり、秀丸マクロ用の変数⇔Perl変数の相互やりとりを行う
    #--------------------------------------------------------------
	sub Macro {
	    my ($class) = @_;
		return $class;
	}

	    #--------------------------------------------------------------
		sub Eval {
		    my ($self, $expression) = @_;
			$hm_Macro_Eval = $expression;
		    return $cmd;
		}

		sub Var {
		    my ($self, $simbol, $value) = @_;
			$hm_Macro_Var_Simbol = $simbol;
			if (undef($value)) {
				return $hm_Macro_Var_Value;
			} else {
				$hm_Macro_Var_Value = $value;
				return $hm_Macro_Var_Value;
			}
		}
	    #--------------------------------------------------------------

    #--------------------------------------------------------------



#--------------------------------------------------------------
# 以下は使わないモノ。プログラムから直接操作するための関数群
#--------------------------------------------------------------
sub __GetVar {
	my ($simbol) = @_;
	${$simbol};
}

sub __SetVar {
	my ($simbol, $value) = @_;
	${$simbol} = $value;
}

sub __GetItemOfList {
	my ($simbol, $index) = @_;
	${$simbol}[$index];
}

sub __SetItemOfList {
	my ($simbol, $index, $value) = @_;
	${$simbol}[$index] = $value;
}

sub __GetItemOfDict {
	my ($simbol, $key) = @_;
	${$simbol}{$key};
}

sub __SetItemOfDict {
	my ($simbol, $key, $value) = @_;
	${$simbol}{$key} = $value;
}
