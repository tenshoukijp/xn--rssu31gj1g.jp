#pragma once

#include "perlez_engine.h"

extern void BindMagicalScalarFunctions(CPerlEzEngine* module);
