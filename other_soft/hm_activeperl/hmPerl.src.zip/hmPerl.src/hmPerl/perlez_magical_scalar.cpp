#include <windows.h>
#include <tchar.h>

#include "convert_string.h"
#include "perlez_magical_scalar.h"
#include "hidemaruexe_export.h"
#include "output_debugstream.h"
#include "self_dll_info.h"
#include "dllfunc_interface.h"
#include "dllfunc_interface_internal.h"

// �V���{���ɃA�N�Z�X����ۂɂ����ɒ��O�̂��̂����Ȃ炸�X�g�b�N�����B
wstring CPerlEzMagicalScalar::stocked_macro_var_simbol = L"";

string CPerlEzMagicalScalar::utf8_getvarofreturn = "";

LPCSTR CPerlEzMagicalScalar::GetHmComposedMagicScalarFunctions(LPVOID obj, LPCSTR p_utf8_SelfName)
{
	utf8_getvarofreturn.clear();

	string utf8_SelfName = p_utf8_SelfName;

	if (utf8_SelfName == "hm_Edit_TotalText") {
		return Hm::Edit::Get::TotalText();
	}
	else if (utf8_SelfName == "hm_Edit_SelectedText") {
		return Hm::Edit::Get::SelectedText();
	}
	else if (utf8_SelfName == "hm_Edit_LineText") {
		return Hm::Edit::Get::LineText();
	}
	else if (utf8_SelfName == "hm_Edit_CursorPos") {
		return Hm::Edit::Get::CursorPos();
	}
	// hm->Macro->Var(...)�ւƓǂݎ��̏ꍇ
	else if (utf8_SelfName == "hm_Macro_Var_Simbol") {
		return Hm::Macro::Get::VarSimbol();
	}

	return "";
}


LPCSTR CPerlEzMagicalScalar::Hm::Edit::Get::TotalText() {
	HGLOBAL hGlobal = CHidemaruExeExport::Hidemaru_GetTotalTextUnicode();
	if (hGlobal) {
		wchar_t* pwsz = (wchar_t*)GlobalLock(hGlobal);
		wstring utf16_Text = wstring(pwsz); // �R�s�[
		GlobalUnlock(hGlobal);
		GlobalFree(hGlobal); // ���͉̂��
		utf8_getvarofreturn = utf16_to_utf8(utf16_Text).data();
		return utf8_getvarofreturn.data();
	}
	return "";
}

LPCSTR CPerlEzMagicalScalar::Hm::Edit::Get::SelectedText() {
	HGLOBAL hGlobal = CHidemaruExeExport::Hidemaru_GetSelectedTextUnicode();
	if (hGlobal) {
		wchar_t* pwsz = (wchar_t*)GlobalLock(hGlobal);
		wstring utf16_Text = wstring(pwsz); // �R�s�[
		GlobalUnlock(hGlobal);
		GlobalFree(hGlobal); // ���͉̂��
		utf8_getvarofreturn = utf16_to_utf8(utf16_Text).data();
		return utf8_getvarofreturn.data();
	}
	return "";
}
LPCSTR CPerlEzMagicalScalar::Hm::Edit::Get::LineText() {
	auto pos = CHidemaruExeExport::Hidemaru_GetCursorPos();
	HGLOBAL hGlobal = CHidemaruExeExport::Hidemaru_GetLineTextUnicode(pos.lineno);
	if (hGlobal) {
		wchar_t* pwsz = (wchar_t*)GlobalLock(hGlobal);
		wstring utf16_Text = wstring(pwsz); // �R�s�[
		GlobalUnlock(hGlobal);
		GlobalFree(hGlobal); // ���͉̂��
		utf8_getvarofreturn = utf16_to_utf8(utf16_Text).data();
		return utf8_getvarofreturn.data();
	}
	return "";
}
LPCSTR CPerlEzMagicalScalar::Hm::Edit::Get::CursorPos() {
	auto pos = CHidemaruExeExport::Hidemaru_GetCursorPos();
	utf8_getvarofreturn = std::to_string(pos.lineno) + "," + std::to_string(pos.column);
	return utf8_getvarofreturn.data();
}
LPCSTR CPerlEzMagicalScalar::Hm::Macro::Get::VarSimbol() {
	int dll = CSelfDllInfo::GetBindDllType();

	TestDynamicVar.Clear();

	// �V���v�����[�h�^�C�v�ł���΁c
	if (dll == -1)
	{

		wstring cmd_single =
			L"##_tmp_pl_dll_id_ret = dllfuncw( \"SetDynamicVar\", " + stocked_macro_var_simbol + L");\n"
			L"##_tmp_pl_dll_id_ret = 0;\n";
		BOOL success = CHidemaruExeExport::Hidemaru_EvalMacro(cmd_single.data());
	}

	// �}���`���[�h�^�C�v�ł���΁c
	else
	{
		wstring cmd_multi =
			L"##_tmp_pl_dll_id_ret = dllfuncw( " + std::to_wstring(dll) + L", \"SetDynamicVar\", " + stocked_macro_var_simbol + L");\n"
			L"##_tmp_pl_dll_id_ret = 0;\n";
		BOOL success = CHidemaruExeExport::Hidemaru_EvalMacro(cmd_multi.data());
	}


	// ���l�Ȃ�
	if (TestDynamicVar.type == CDynamicValue::TDynamicType::TypeInteger)
	{
		return std::to_string(TestDynamicVar.num).data();
	}
	// ������Ȃ�
	else {
		return utf16_to_utf8(TestDynamicVar.wstr).data();
	}
}




string CPerlEzMagicalScalar::utf8_setvarofreturn = "";
LPCSTR CPerlEzMagicalScalar::SetHmComposedMagicScalarFunctions(LPVOID obj, LPCSTR p_utf8_SelfName, LPCSTR p_utf8_Value)
{
	utf8_setvarofreturn.clear();

	string utf8_SelfName = p_utf8_SelfName;
	wstring utf16_value = utf8_to_utf16(p_utf8_Value);

	// hm->debuginfo(...)�����s
	if (utf8_SelfName == "hm_debuginfo") {
		CPerlEzMagicalScalar::Hm::debuginfo(utf16_value);
		return p_utf8_Value;
	}

	// hm->Macro->Eval(...)�����s
	else if (utf8_SelfName == "hm_Macro_Eval") {
		int ret = CPerlEzMagicalScalar::Hm::Macro::Eval(utf16_value);
		return ret ? p_utf8_Value : "";
	}

	// hm->Edit->TodalText(...)�ւƑ��
	else if (utf8_SelfName == "hm_Edit_TotalText") {
		int ret = CPerlEzMagicalScalar::Hm::Edit::Set::TotalText(utf16_value);
		return ret ? p_utf8_Value : "";
	}

	// hm->Edit->SelectedText(...)�ւƑ��
	else if (utf8_SelfName == "hm_Edit_SelectedText") {
		int ret = CPerlEzMagicalScalar::Hm::Edit::Set::SelectedText(utf16_value);
		return ret ? p_utf8_Value : "";
	}
	// hm->Edit->LineText(...)�ւƑ��
	else if (utf8_SelfName == "hm_Edit_LineText") {
		int ret = CPerlEzMagicalScalar::Hm::Edit::Set::LineText(utf16_value);
		return ret ? p_utf8_Value : "";
	}

	// hm->Macro->Var(...)�ւƑ���̑O��
	else if (utf8_SelfName == "hm_Macro_Var_Simbol") {
		int ret = CPerlEzMagicalScalar::Hm::Macro::Set::VarSimbol(utf16_value);
		return ret ? p_utf8_Value : "";
	}
	// hm->Macro->Var(...)�ւƑ���̌㔼
	else if (utf8_SelfName == "hm_Macro_Var_Value") {
		int ret = CPerlEzMagicalScalar::Hm::Macro::Set::VarValue(utf16_value);
		return ret ? p_utf8_Value : "";
	}

	// MessageBox(NULL, L"��������", L"��������", NULL);
	// MessageBox(NULL, utf8_to_utf16(p_utf8_SelfName).data(), utf8_to_utf16(p_utf8_Value).data(), NULL);
	return p_utf8_Value;
}


BOOL CPerlEzMagicalScalar::Hm::debuginfo(wstring utf16_value) {
	OutputDebugStream(utf16_value);
	return TRUE;
}

BOOL CPerlEzMagicalScalar::Hm::Macro::Eval(wstring utf16_value) {
	BOOL success = CHidemaruExeExport::Hidemaru_EvalMacro(utf16_value.data());
	if (success) {
		return TRUE;
	}
	OutputDebugStream(L"�}�N���̎��s�Ɏ��s���܂����B\n");
	OutputDebugStream(L"�}�N�����e:\n");
	OutputDebugStream(utf16_value);
	return FALSE;
}


BOOL CPerlEzMagicalScalar::Hm::Edit::Set::TotalText(wstring utf16_value) {
	int dll = CSelfDllInfo::GetBindDllType();
	BOOL success = 0;

	// �V���v�����[�h�^�C�v�ł���΁c
	if (dll == -1)
	{
		PushStrVar(utf16_value.data());
		wstring cmd_single = L"begingroupundo;\n"
			L"selectall;\n"
			L"insert dllfuncstrw( \"PopStrVar\" );\n"
			L"endgroupundo;\n";
		success = CHidemaruExeExport::Hidemaru_EvalMacro(cmd_single.data());
	}

	// �}���`���[�h�^�C�v�ł���΁c
	else
	{
		PushStrVar(utf16_value.data());
		wstring cmd_multi = L"begingroupundo;\n"
			L"selectall;\n"
			L"insert dllfuncstrw( " + std::to_wstring(dll) + L", \"PopStrVar\" );\n"
			L"endgroupundo;\n";
		success = CHidemaruExeExport::Hidemaru_EvalMacro(cmd_multi.data());
	}

	return success;
}

BOOL CPerlEzMagicalScalar::Hm::Edit::Set::SelectedText(wstring utf16_value) {
	int dll = CSelfDllInfo::GetBindDllType();
	BOOL success = 0;

	// �V���v�����[�h�^�C�v�ł���΁c
	if (dll == -1)
	{
		PushStrVar(utf16_value.data());
		wstring cmd_single = L"if (selecting) {\n"
			L"insert dllfuncstrw( \"PopStrVar\" );\n"
			L"}\n";
		success = CHidemaruExeExport::Hidemaru_EvalMacro(cmd_single.data());
	}

	// �}���`���[�h�^�C�v�ł���΁c
	else
	{
		PushStrVar(utf16_value.data());
		wstring cmd_multi = L"if (selecting) {\n"
			L"insert dllfuncstrw( " + std::to_wstring(dll) + L", \"PopStrVar\" );\n"
			L"};\n";
		success = CHidemaruExeExport::Hidemaru_EvalMacro(cmd_multi.data());
	}

	return success;
}

BOOL CPerlEzMagicalScalar::Hm::Edit::Set::LineText(wstring utf16_value) {
	int dll = CSelfDllInfo::GetBindDllType();
	BOOL success = 0;

	// �V���v�����[�h�^�C�v�ł���΁c
	if (dll == -1)
	{
		auto pos = CHidemaruExeExport::Hidemaru_GetCursorPos();
		PushStrVar(utf16_value.data());
		wstring cmd_single = L"begingroupundo;\n"
			L"selectline;\n"
			L"insert dllfuncstrw( \"PopStrVar\" );\n"
			L"moveto2 " + std::to_wstring(pos.column) + L", " + std::to_wstring(pos.lineno) + L";\n" +
			L"endgroupundo;\n";
		success = CHidemaruExeExport::Hidemaru_EvalMacro(cmd_single.data());
	}

	// �}���`���[�h�^�C�v�ł���΁c
	else
	{
		auto pos = CHidemaruExeExport::Hidemaru_GetCursorPos();
		PushStrVar(utf16_value.data());
		wstring cmd_multi = L"begingroupundo;\n"
			L"selectline;\n"
			L"insert dllfuncstrw( " + std::to_wstring(dll) + L", \"PopStrVar\" );\n"
			L"moveto2 " + std::to_wstring(pos.column) + L", " + std::to_wstring(pos.lineno) + L";\n" +
			L"endgroupundo;\n";
		success = CHidemaruExeExport::Hidemaru_EvalMacro(cmd_multi.data());
	}

	return success;
}

BOOL CPerlEzMagicalScalar::Hm::Macro::Set::VarSimbol(wstring utf16_value) {
	stocked_macro_var_simbol = utf16_value;
	return TRUE;
}

BOOL CPerlEzMagicalScalar::Hm::Macro::Set::VarValue(wstring utf16_value) {

	int dll = CSelfDllInfo::GetBindDllType();
	BOOL success = 0;

	wchar_t start = stocked_macro_var_simbol[0];
	if (start == L'#') {
		// �����𐔒l�Ƀg���C�B�_���Ȃ�0����B
		int n = 0;
		try {
			n = std::stoi(utf16_value);
		}
		catch (...) {}

		// �V���v�����[�h�^�C�v�ł���΁c
		if (dll == -1)
		{

			PushNumVar(n);
			wstring cmd_single = L" = dllfuncw( \"PopNumVar\" );\n";
			cmd_single = stocked_macro_var_simbol + cmd_single;
			success = CHidemaruExeExport::Hidemaru_EvalMacro(cmd_single.data());
		}

		// �}���`���[�h�^�C�v�ł���΁c
		else
		{
			PushNumVar(n);
			wstring cmd_multi = L" = dllfuncw( " + std::to_wstring(dll) + L", \"PopNumVar\" );\n";
			cmd_multi = stocked_macro_var_simbol + cmd_multi;
			success = CHidemaruExeExport::Hidemaru_EvalMacro(cmd_multi.data());
		}
	}
	else if (start == L'$') {

		// �V���v�����[�h�^�C�v�ł���΁c
		if (dll == -1)
		{
			PushStrVar(utf16_value.data());
			wstring cmd_single = stocked_macro_var_simbol +
				L" = dllfuncstrw( \"PopStrVar\" );\n";
			success = CHidemaruExeExport::Hidemaru_EvalMacro(cmd_single.data());
		}

		// �}���`���[�h�^�C�v�ł���΁c
		else
		{
			PushStrVar(utf16_value.data());
			wstring cmd_multi = stocked_macro_var_simbol +
				L" = dllfuncstrw( " + std::to_wstring(dll) + L", \"PopStrVar\" );\n";
			success = CHidemaruExeExport::Hidemaru_EvalMacro(cmd_multi.data());
		}
	}

	return success;
}

void CPerlEzMagicalScalar::BindMagicalScalarFunctions(CPerlEzEngine* module) {
	auto& engine = module->engine;

	// �S�Ẵv���p�e�B(�I�ȃO���[�o���ϐ�)�Ƀt�b�N�����AGet��Set�̊֐���o�^
	module->PerlEzSetMagicScalarFunctions(engine, CPerlEzMagicalScalar::GetHmComposedMagicScalarFunctions, CPerlEzMagicalScalar::SetHmComposedMagicScalarFunctions);

	// ��L�֐����@�\������O���[�o���ϐ���o�^���Ă����B
	module->PerlEzSetMagicScalarName(engine, "hm_debuginfo");
	module->PerlEzSetMagicScalarName(engine, "hm_Macro_Var_Simbol");
	module->PerlEzSetMagicScalarName(engine, "hm_Macro_Var_Value");
	module->PerlEzSetMagicScalarName(engine, "hm_Macro_Eval");
	module->PerlEzSetMagicScalarName(engine, "hm_Edit_TotalText");
	module->PerlEzSetMagicScalarName(engine, "hm_Edit_SelectedText");
	module->PerlEzSetMagicScalarName(engine, "hm_Edit_LineText");
	module->PerlEzSetMagicScalarName(engine, "hm_Edit_CursorPos");
}