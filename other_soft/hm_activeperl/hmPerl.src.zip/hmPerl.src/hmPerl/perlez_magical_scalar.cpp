#include <windows.h>
#include <tchar.h>

#include "convert_string.h"
#include "perlez_magical_scalar.h"
#include "hidemaruexe_export.h"
#include "outputdebugstream.h"
#include "self_dll_info.h"
#include "dllfunc_interface.h"

// �V���{���ɃA�N�Z�X����ۂɂ����ɒ��O�̂��̂����Ȃ炸�X�g�b�N�����B
static wstring stocked_macro_var_simbol = L"";

static string utf8_getvarofreturn = "";
// ���p�����͈̔͂������肵�Ȃ��̂Ŗ��Ȃ��Ƃ������f
LPCSTR GetHmComposedMagicScalarFunctions(LPVOID obj, LPCSTR p_utf8_SelfName)
{
	utf8_getvarofreturn.clear();

	string utf8_SelfName = p_utf8_SelfName;

	if (utf8_SelfName == "hm_Edit_TotalText") {
		HGLOBAL hGlobal = CHidemaruExeExport::Hidemaru_GetTotalTextUnicode();
		if (hGlobal) {
			wchar_t* pwsz = (wchar_t*)GlobalLock(hGlobal);
			wstring utf16_Text = wstring(pwsz); // �R�s�[
			GlobalUnlock(hGlobal);
			GlobalFree(hGlobal); // ���͉̂��
			utf8_getvarofreturn = utf16_to_utf8(utf16_Text).data();
			return utf8_getvarofreturn.data();
		}
		return "";
	}
	else if (utf8_SelfName == "hm_Edit_SelectedText") {
		HGLOBAL hGlobal = CHidemaruExeExport::Hidemaru_GetSelectedTextUnicode();
		if (hGlobal) {
			wchar_t* pwsz = (wchar_t*)GlobalLock(hGlobal);
			wstring utf16_Text = wstring(pwsz); // �R�s�[
			GlobalUnlock(hGlobal);
			GlobalFree(hGlobal); // ���͉̂��
			utf8_getvarofreturn = utf16_to_utf8(utf16_Text).data();
			return utf8_getvarofreturn.data();
		}
		return "";
	}
	else if (utf8_SelfName == "hm_Edit_LineText") {
		auto pos = CHidemaruExeExport::Hidemaru_GetCursorPos();
		HGLOBAL hGlobal = CHidemaruExeExport::Hidemaru_GetLineTextUnicode(pos.lineno);
		if (hGlobal) {
			wchar_t* pwsz = (wchar_t*)GlobalLock(hGlobal);
			wstring utf16_Text = wstring(pwsz); // �R�s�[
			GlobalUnlock(hGlobal);
			GlobalFree(hGlobal); // ���͉̂��
			utf8_getvarofreturn = utf16_to_utf8(utf16_Text).data();
			return utf8_getvarofreturn.data();
		}
		return "";
	}
	else if (utf8_SelfName == "hm_Edit_CursorPos") {
		auto pos = CHidemaruExeExport::Hidemaru_GetCursorPos();
		utf8_getvarofreturn = std::to_string(pos.lineno) + "," + std::to_string(pos.column);
		return utf8_getvarofreturn.data();
	}
	// hm->Macro->Var(...)�ւƓǂݎ��̏ꍇ
	else if (utf8_SelfName == "hm_Macro_Var_Simbol") {
		int dll = CSelfDllInfo::iSelfBindedType;

		ClearTmpDynamicVar();

		// �V���v�����[�h�^�C�v�ł���΁c
		if (dll == -1)
		{

			wstring cmd_single = 
				L"##_tmp_pl_dll_id_ret = dllfuncw( \"SetTmpVar\", " + stocked_macro_var_simbol + L");\n"
				L"##_tmp_pl_dll_id_ret = 0;\n";
			BOOL success = CHidemaruExeExport::Hidemaru_EvalMacro(cmd_single.data());
		}

		// �}���`���[�h�^�C�v�ł���΁c
		else
		{
			wstring cmd_multi =
				L"##_tmp_pl_dll_id_ret = dllfuncw( " + std::to_wstring(dll) + L", \"SetTmpVar\", " + stocked_macro_var_simbol + L");\n"
				L"##_tmp_pl_dll_id_ret = 0;\n";
			BOOL success = CHidemaruExeExport::Hidemaru_EvalMacro(cmd_multi.data());
		}

		auto tmpDynamicVar = GetTmpDynamicVar();

		// ���l�Ȃ�
		if (tmpDynamicVar.type_name == "int")
		{
			return std::to_string(tmpDynamicVar.dynamic_value.iNum).data();
		}
		// ������Ȃ�
		else {
			return utf16_to_utf8(tmpDynamicVar.dynamic_value.pWStr).data();
		}
	}

	return "";
}



static string utf8_setvarofreturn = "";
LPCSTR SetHmComposedMagicScalarFunctions(LPVOID obj, LPCSTR p_utf8_SelfName, LPCSTR p_utf8_Value)
{
	utf8_setvarofreturn.clear();

	string utf8_SelfName = p_utf8_SelfName;
	wstring utf16_value = utf8_to_utf16(p_utf8_Value);

	// hm->debuginfo(...)�����s
	if (utf8_SelfName == "hm_debuginfo") {
		OutputDebugStream(utf16_value);
		return p_utf8_Value;
	}

	// hm->Macro->Eval(...)�����s
	else if (utf8_SelfName == "hm_Macro_Eval") {
		BOOL success = CHidemaruExeExport::Hidemaru_EvalMacro(utf16_value.data());
		if (success) {
			return "1";
		}
		OutputDebugStream(L"�}�N���̎��s�Ɏ��s���܂����B\n");
		OutputDebugStream(L"�}�N�����e:\n");
		OutputDebugStream(utf16_value);
		return "0";
	}

	// hm->Edit->TodalText(...)�ւƑ��
	else if (utf8_SelfName == "hm_Edit_TotalText") {
		int dll = CSelfDllInfo::iSelfBindedType;

		// �V���v�����[�h�^�C�v�ł���΁c
		if (dll == -1)
		{
			PushStrVar(utf16_value.data());
			wstring cmd_single = L"begingroupundo;\n" 
				L"selectall;\n"
				L"insert dllfuncstrw( \"PopStrVar\" );\n"
				L"endgroupundo;\n";
			BOOL success = CHidemaruExeExport::Hidemaru_EvalMacro(cmd_single.data());
		}

		// �}���`���[�h�^�C�v�ł���΁c
		else
		{
			PushStrVar(utf16_value.data());
			wstring cmd_multi = L"begingroupundo;\n"
				L"selectall;\n" 
				L"insert dllfuncstrw( " + std::to_wstring(dll) + L", \"PopStrVar\" );\n"
				L"endgroupundo;\n";
			BOOL success = CHidemaruExeExport::Hidemaru_EvalMacro(cmd_multi.data());
		}
	}

	// hm->Edit->SelectedText(...)�ւƑ��
	else if (utf8_SelfName == "hm_Edit_SelectedText") {
		int dll = CSelfDllInfo::iSelfBindedType;

		// �V���v�����[�h�^�C�v�ł���΁c
		if (dll == -1)
		{
			PushStrVar(utf16_value.data());
			wstring cmd_single = L"if (selecting) {\n"
				L"insert dllfuncstrw( \"PopStrVar\" );\n"
				L"}\n";
			BOOL success = CHidemaruExeExport::Hidemaru_EvalMacro(cmd_single.data());
		}

		// �}���`���[�h�^�C�v�ł���΁c
		else
		{
			PushStrVar(utf16_value.data());
			wstring cmd_multi = L"if (selecting) {\n"
				L"insert dllfuncstrw( " + std::to_wstring(dll) + L", \"PopStrVar\" );\n"
				L"};\n";
			BOOL success = CHidemaruExeExport::Hidemaru_EvalMacro(cmd_multi.data());
		}
	}
	// hm->Edit->LineText(...)�ւƑ��
	else if (utf8_SelfName == "hm_Edit_LineText") {
		int dll = CSelfDllInfo::iSelfBindedType;

		// �V���v�����[�h�^�C�v�ł���΁c
		if (dll == -1)
		{
			auto pos = CHidemaruExeExport::Hidemaru_GetCursorPos();
			PushStrVar(utf16_value.data());
			wstring cmd_single = L"begingroupundo;\n"
				L"selectline;\n"
				L"insert dllfuncstrw( \"PopStrVar\" );\n"
				L"moveto2 " + std::to_wstring(pos.column) + L", " + std::to_wstring(pos.lineno) + L";\n" +
				L"endgroupundo;\n";
			BOOL success = CHidemaruExeExport::Hidemaru_EvalMacro(cmd_single.data());
		}

		// �}���`���[�h�^�C�v�ł���΁c
		else
		{
			auto pos = CHidemaruExeExport::Hidemaru_GetCursorPos();
			PushStrVar(utf16_value.data());
			wstring cmd_multi = L"begingroupundo;\n"
				L"selectline;\n"
				L"insert dllfuncstrw( " + std::to_wstring(dll) + L", \"PopStrVar\" );\n"
				L"moveto2 " + std::to_wstring(pos.column) + L", " + std::to_wstring(pos.lineno) + L";\n" +
				L"endgroupundo;\n";
			BOOL success = CHidemaruExeExport::Hidemaru_EvalMacro(cmd_multi.data());
		}
	}

	// hm->Macro->Var(...)�ւƑ���̑O��
	else if (utf8_SelfName == "hm_Macro_Var_Simbol") {
		stocked_macro_var_simbol = utf16_value;
	}
	// hm->Macro->Var(...)�ւƑ���̌㔼
	else if (utf8_SelfName == "hm_Macro_Var_Value") {

		int dll = CSelfDllInfo::iSelfBindedType;

		wchar_t start = stocked_macro_var_simbol[0];
		if (start == L'#') {
			// �����𐔒l�Ƀg���C�B�_���Ȃ�0����B
			int n = 0;
			try {
				n = std::stoi(utf16_value);
			}
			catch (...) {}

			// �V���v�����[�h�^�C�v�ł���΁c
			if (dll == -1)
			{

				PushNumVar(n);
				wstring cmd_single = L" = dllfuncw( \"PopNumVar\" );\n";
				cmd_single = stocked_macro_var_simbol + cmd_single;
				BOOL success = CHidemaruExeExport::Hidemaru_EvalMacro(cmd_single.data());
			}

			// �}���`���[�h�^�C�v�ł���΁c
			else
			{
				PushNumVar(n);
				wstring cmd_multi = L" = dllfuncw( " + std::to_wstring(dll) + L", \"PopNumVar\" );\n";
				cmd_multi = stocked_macro_var_simbol + cmd_multi;
				BOOL success = CHidemaruExeExport::Hidemaru_EvalMacro(cmd_multi.data());
			}
		}
		else if (start == L'$') {

			// �V���v�����[�h�^�C�v�ł���΁c
			if (dll == -1)
			{
				PushStrVar(utf16_value.data());
				wstring cmd_single = stocked_macro_var_simbol +
					L" = dllfuncstrw( \"PopStrVar\" );\n";
				BOOL success = CHidemaruExeExport::Hidemaru_EvalMacro(cmd_single.data());
			}

			// �}���`���[�h�^�C�v�ł���΁c
			else
			{
				PushStrVar(utf16_value.data());
				wstring cmd_multi = stocked_macro_var_simbol +
					L" = dllfuncstrw( " + std::to_wstring(dll) + L", \"PopStrVar\" );\n";
				BOOL success = CHidemaruExeExport::Hidemaru_EvalMacro(cmd_multi.data());
			}
		}
	}

	// MessageBox(NULL, L"��������", L"��������", NULL);
	// MessageBox(NULL, utf8_to_utf16(p_utf8_SelfName).data(), utf8_to_utf16(p_utf8_Value).data(), NULL);
	return p_utf8_Value;
}

void BindMagicalScalarFunctions(CPerlEzEngine* module) {
	auto& engine = module->engine;
	module->PerlEzSetMagicScalarFunctions(engine, GetHmComposedMagicScalarFunctions, SetHmComposedMagicScalarFunctions);
	module->PerlEzSetMagicScalarName(engine, "hm_debuginfo");
	module->PerlEzSetMagicScalarName(engine, "hm_Macro_Var_Simbol");
	module->PerlEzSetMagicScalarName(engine, "hm_Macro_Var_Value");
	module->PerlEzSetMagicScalarName(engine, "hm_Macro_Eval");
	module->PerlEzSetMagicScalarName(engine, "hm_Edit_TotalText");
	module->PerlEzSetMagicScalarName(engine, "hm_Edit_SelectedText");
	module->PerlEzSetMagicScalarName(engine, "hm_Edit_LineText");
	module->PerlEzSetMagicScalarName(engine, "hm_Edit_CursorPos");
}