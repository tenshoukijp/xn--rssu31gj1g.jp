#pragma once

#include <tchar.h>

void OutputDebugStream(wstring wstr);

void OutputDebugErrMsg();