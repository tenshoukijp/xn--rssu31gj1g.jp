#include <windows.h>

#include "self_dll_info.h"

HMODULE CSelfDllInfo::hModule = nullptr;

TCHAR CSelfDllInfo::szSelfModuleFullPath[MAX_PATH] = L"";

int CSelfDllInfo::iSelfBindedType = 0;
