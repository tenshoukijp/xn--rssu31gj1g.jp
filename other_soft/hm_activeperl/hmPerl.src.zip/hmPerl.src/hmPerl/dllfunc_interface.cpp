﻿#include <stdio.h>
#include <windows.h>
#include <tchar.h>

#include "convert_string.h"
#include "perlez_engine.h"
#include "perlez_magical_scalar.h"
#include "hidemaruexe_export.h"
#include "self_dll_info.h"

#include "dllfunc_interface.h"

#include "outputdebugstream.h"

using namespace std;



CPerlEzEngine *module = NULL;
static int CreateScope() {

	// すでに生成済みである。
	if (CPerlEzEngine::IsValid()) {
		return TRUE;
	}

	module = new CPerlEzEngine();
	if (!module->IsValid()) {
		return FALSE;
	}

	BindMagicalScalarFunctions(module);
	return TRUE;
}

static BOOL BindDllHandle() {
	// 本体からの関数の生成が先
	CHidemaruExeExport::init();

	// 秀丸8.66以上
	if (CHidemaruExeExport::Hidemaru_GetDllFuncCalledType) {
		int dll = CHidemaruExeExport::Hidemaru_GetDllFuncCalledType(-1); // 自分のdllの呼ばれ方をチェック
		CSelfDllInfo::iSelfBindedType = dll;
		return TRUE;
	}
	else {
		MessageBox(NULL, L"loadllのパターンが認識出来ませんでした。", L"loadllのパターンが認識出来ませんでした。", MB_ICONERROR);
	}
	return FALSE;

}




static DYNAMIC_VALUE tmpDynamicVar;
void ClearTmpDynamicVar() {
	ZeroMemory(&tmpDynamicVar, sizeof(DYNAMIC_VALUE));
}

DYNAMIC_VALUE GetTmpDynamicVar() {
	return tmpDynamicVar;
}


// 秀丸の変数が文字列か数値かの判定用
MACRO_DLL int SetTmpVar(const void* dynamic_value) {
	auto param_type = (CHidemaruExeExport::DLLFUNCPARAM)CHidemaruExeExport::Hidemaru_GetDllFuncCalledType(1); // 2番目の引数の型。１番目は関数名なので、２番目は
	DYNAMIC_VALUE dvalue;
	if (param_type == CHidemaruExeExport::DLLFUNCPARAM::WCHAR_PTR) {
		tmpDynamicVar.dynamic_value.pWStr = (wchar_t *)dynamic_value;
		tmpDynamicVar.type_name = "string";
		return 1;
	}
	else {
		tmpDynamicVar.dynamic_value.iNum = (int)dynamic_value;
		tmpDynamicVar.type_name = "int";
		return 1;
	}
}


//------------------------------------------------------------------------------------
MACRO_DLL int GetNumVar(const TCHAR *sz_full_var_name) {
	if (CreateScope() == 0)
	{
		return 0;
	}

	// 絶対に２文字は必要
	if (_tcslen(sz_full_var_name) < 2) {
		return 0;
	}

	char utf8_buffer[4096] = "";

	// 最初の記号は除いた文字。チェックしても無駄なのでチェックしない。
	const TCHAR *sz_var_name = sz_full_var_name + 1;

	int ret = module->PerlEzCall(
		module->engine,
		"__GetVar",
		utf8_buffer,
		_countof(utf8_buffer),
		"s",
		utf16_to_utf8(sz_var_name).data()
	);

	// 成功
	if (ret == plezNoError) {
		// 数字→数値の変換
		try {
			wstring strnum = utf8_to_utf16(utf8_buffer);
			return std::stoi(strnum);
		}
		catch (...) {

		}
	}
	OutputDebugErrMsg();
	// 失敗したらトレース枠に
	OutputDebugStream(utf8_to_utf16(utf8_buffer));

	// 失敗したら0
	return 0;
}

MACRO_DLL int SetNumVar(const TCHAR *sz_full_var_name, int value) {
	if (CreateScope() == 0)
	{
		return 0;
	}

	// 絶対に２文字は必要
	if (_tcslen(sz_full_var_name) < 2) {
		return 0;
	}

	char utf8_buffer[4096] = "";
	// 最初の記号は除いた文字。チェックしても無駄なのでチェックしない。
	const TCHAR *sz_var_name = sz_full_var_name + 1;

	int ret = module->PerlEzCall(
		module->engine,
		"__SetVar",
		utf8_buffer,
		_countof(utf8_buffer),
		"si",
		utf16_to_utf8(sz_var_name).data(),
		value
		);

	// 成功
	if (ret == plezNoError) {
		return 1;
	}
	OutputDebugErrMsg();
		// 失敗したらトレース枠に
	OutputDebugStream(utf8_to_utf16(utf8_buffer));

	// 失敗したら0
	return 0;
}

// 秀丸のキャッシュのため
static wstring strvars;
MACRO_DLL const TCHAR * GetStrVar(const TCHAR *sz_full_var_name) {
	// クリア必須
	strvars.clear();

	if (CreateScope() == 0)
	{
		return 0;
	}

	// 絶対に２文字は必要
	if (_tcslen(sz_full_var_name) < 2) {
		return 0;
	}

	char utf8_buffer[4096] = "";

	// 最初の記号は除いた文字。チェックしても無駄なのでチェックしない。
	const TCHAR *sz_var_name = sz_full_var_name + 1;

	int ret = module->PerlEzCall(
		module->engine,
		"__GetVar",
		utf8_buffer,
		_countof(utf8_buffer),
		"s",
		utf16_to_utf8(sz_var_name).data()
		);

	// 成功
	if (ret == plezNoError) {
		strvars = utf8_to_utf16(utf8_buffer);
		return strvars.data();
	}

	OutputDebugErrMsg();
		// 失敗したらトレース枠に
	OutputDebugStream(utf8_to_utf16(utf8_buffer));

	// 失敗したら""
	return L"";
}

MACRO_DLL int SetStrVar(const TCHAR *sz_full_var_name, const TCHAR *value) {
	if (CreateScope() == 0)
	{
		return 0;
	}

	// 絶対に２文字は必要
	if (_tcslen(sz_full_var_name) < 2) {
		return 0;
	}

	char utf8_buffer[4096] = "";
	// 最初の記号は除いた文字。チェックしても無駄なのでチェックしない。
	const TCHAR *sz_var_name = sz_full_var_name + 1;

	int ret = module->PerlEzCall(
		module->engine,
		"__SetVar",
		utf8_buffer,
		_countof(utf8_buffer),
		"ss",
		utf16_to_utf8(sz_var_name).data(),
		utf16_to_utf8(value).data()
		);

	// 成功
	if (ret == plezNoError) {
		return 1;
	}
	OutputDebugErrMsg();
		// 失敗したらトレース枠に
	OutputDebugStream(utf8_to_utf16(utf8_buffer));

	// 失敗したら0
	return 0;
}

int popnumvar = 0;
// スタックした変数を秀丸マクロから取り出す。内部処理用
MACRO_DLL int PopNumVar() {
	return popnumvar;
}

// 変数を秀丸マクロから取り出すためにスタック。内部処理用
MACRO_DLL int PushNumVar(int i_tmp_num) {
	popnumvar = i_tmp_num;
	return 1;
}

// スタックした変数を秀丸マクロから取り出す。内部処理用
static wstring popstrvar;
MACRO_DLL const TCHAR * PopStrVar() {
	return popstrvar.data();
}

// 変数を秀丸マクロから取り出すためにスタック。内部処理用
MACRO_DLL int PushStrVar(const TCHAR *sz_tmp_str) {
	popstrvar = sz_tmp_str;
	return 1;
}


MACRO_DLL int DoString(const TCHAR *szexpression) {
	if (CreateScope() == 0)
	{
		return 0;
	}

	// DoStringされる度にdllのBindの在り方を確認更新する。
	BindDllHandle();

	auto rtn_type = (CHidemaruExeExport::DLLFUNCRETURN)CHidemaruExeExport::Hidemaru_GetDllFuncCalledType(0); // 0は返り値の型
	if (rtn_type == CHidemaruExeExport::DLLFUNCRETURN::CHAR_PTR || rtn_type == CHidemaruExeExport::DLLFUNCRETURN::WCHAR_PTR) {
		MessageBox(NULL, L"返り値の型が異なります。\ndllfuncstrではなく、dllfuncw文を利用してください。", L"返り値の型が異なります", MB_ICONERROR);
	}

	auto arg_type = (CHidemaruExeExport::DLLFUNCPARAM)CHidemaruExeExport::Hidemaru_GetDllFuncCalledType(1); // 1は1番目の引数
	if (arg_type != CHidemaruExeExport::DLLFUNCPARAM::WCHAR_PTR) {
		MessageBox(NULL, L"引数の型が異なります。\ndllfuncではなく、dllfuncw文を利用してください。", L"引数の型が異なります", MB_ICONERROR);
	}

	string utf8_expression = utf16_to_utf8(szexpression);
	char utf8_buffer[4096] = "";

	int ret = module->PerlEzEvalString(
		module->engine,
		utf8_expression.data(),
		utf8_buffer,
		_countof(utf8_buffer)
	);

	// 成功
	if (ret == plezNoError) {
		return 1;
	}

	OutputDebugErrMsg();
		// 失敗したらトレース枠に
	OutputDebugStream(utf8_to_utf16(utf8_buffer));

	// 失敗したら0
	return 0;
}


MACRO_DLL int DestroyScope() {
	if (module) {

		char utf8_buffer[4096] = "";
		int ret = module->PerlEzCall(
			module->engine,
			"DestroyScope",
			utf8_buffer,
			_countof(utf8_buffer),
			""
		);

		delete module;
		module = NULL;

	}

	ClearTmpDynamicVar();

	return TRUE;
}


MACRO_DLL int DllDetachFunc_After_Hm866() {
	return DestroyScope();
}