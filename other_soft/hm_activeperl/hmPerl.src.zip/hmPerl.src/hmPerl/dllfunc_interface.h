#pragma once

#include <tchar.h>

#define MACRO_DLL extern "C" __declspec(dllexport)

//========================================================================
/// ���̃t�@�C�����猩�Ă��邽�߂�extern�B���ۂ�.cpp�̕����݂Ă�
//========================================================================
MACRO_DLL int GetNumVar(const TCHAR *sz_full_var_name);
MACRO_DLL int SetNumVar(const TCHAR *sz_full_var_name, int value);
MACRO_DLL const TCHAR * GetStrVar(const TCHAR *sz_full_var_name);
MACRO_DLL int SetStrVar(const TCHAR *sz_full_var_name, const TCHAR *value);
