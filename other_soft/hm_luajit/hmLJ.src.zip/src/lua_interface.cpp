// copyright (c) 2016 �V�ċL.jp

#define MACRO_DLL extern "C" __declspec(dllexport)

#include <map>
#include "sol.hpp"
#include "OutputDebugStream.h"
#include <windows.h>

using namespace std;

// �p�j�b�N�ɂȂ������悤�ɌĂ΂��֐�
int atpanic(lua_State *L)
{
	throw std::runtime_error(lua_tostring(L, -1));
}
int le_trace(lua_State *L)
{
	int n = lua_gettop(L);
	for (int i = 1; i <= n; i++) {
		lua_getglobal(L, "tostring");
		lua_pushvalue(L, i);
		lua_pcall(L, 1, 1, 0);
		const char *str = lua_tostring(L, -1);
		lua_OutputDebugStream(str);
		lua_pop(L, 1);
	}
	lua_OutputDebugStream("\n");
	return 0;
}


// create an empty lua state
sol::state lua;

void LoadLuaInterpreter() {

	lua.open_libraries(sol::lib::base);
	lua.open_libraries(sol::lib::package);
	lua.open_libraries(sol::lib::coroutine);
	lua.open_libraries(sol::lib::string);
	lua.open_libraries(sol::lib::table);
	lua.open_libraries(sol::lib::math);
	lua.open_libraries(sol::lib::bit);
	lua.open_libraries(sol::lib::bit32);
	lua.open_libraries(sol::lib::io);
	lua.open_libraries(sol::lib::os);
	lua.open_libraries(sol::lib::debug);
	lua.open_libraries(sol::lib::ffi);
	lua.open_libraries(sol::lib::jit);
	lua.open_libraries(sol::lib::lfs);
	lua.open_libraries(sol::lib::utf8);
	lua.open_libraries(sol::lib::cp932);
	lua.open_libraries(sol::lib::cjson);

	// �p�j�b�N�ɂȂ����炱����Ă�ł�
	lua_atpanic(lua.lua_state(), atpanic);
}


void FreeLuaInterpreter() {
	string expression = R"(
		if DestroyScope and type(DestroyScope) == "function" then
			DestroyScope()
        end
	)";

	lua.script(expression);
}


MACRO_DLL int GetNumVar(const char *sz_var_name) {
	try {
		string var_name = string(sz_var_name);
		sol::object value = lua[var_name];
		return value.as<int>();
	}
	catch (std::exception& e) {
		lua_OutputDebugStream("%s\n", e.what());
		return 0;
	}
}

MACRO_DLL int SetNumVar(const char *sz_var_name, int value) {
	try {
		string var_name = string(sz_var_name);
		lua[var_name] = value;
		return TRUE;
	}
	catch (std::exception& e) {
		lua_OutputDebugStream("%s\n", e.what());
		return FALSE;
	}
}

string strvars;
MACRO_DLL const char* GetStrVar(const char *sz_var_name) {
	try {
		string var_name = string(sz_var_name);
		sol::object value = lua[var_name];
		strvars = value.as<std::string>();
		// �ۑ����Ă�����̃|�C���^��Ԃ��K�v������B
		return strvars.data();
	}
	catch (std::exception& e) {
		lua_OutputDebugStream("%s\n", e.what());
		return "";
	}
}

MACRO_DLL int SetStrVar(const char *sz_var_name, const char *value) {
	try {
		string var_name = string(sz_var_name);
		lua[var_name] = string(value);
		return TRUE;
	}
	catch (std::exception& e) {
		lua_OutputDebugStream("%s\n", e.what());
		return FALSE;
	}
}


MACRO_DLL int GetNumItemOfList(const char *sz_arr_name, int ix) {
	try {
		string arr_name = string(sz_arr_name);
		sol::object tbl = lua[arr_name];
		sol::type t = tbl.get_type();
		// �{���Ƀe�[�u���ł���΁c
		if (t == sol::type::table) {
			sol::object value = lua[arr_name][ix];
			return value.as<int>();
		}
		return 0;
	}
	catch (std::exception& e) {
		lua_OutputDebugStream("%s\n", e.what());
		return 0;
	}

}

MACRO_DLL int SetNumItemOfList(const char *sz_arr_name, int ix, int value) {
	try {
		string arr_name = string(sz_arr_name);
		sol::object tbl = lua[arr_name];
		sol::type t = tbl.get_type();
		// �{���Ƀe�[�u���ł���΁c
		if (t == sol::type::table) {
			lua[arr_name][ix] = value;
			return TRUE;
		}
		return FALSE;
	}
	catch (std::exception& e) {
		lua_OutputDebugStream("%s\n", e.what());
		return FALSE;
	}
}

string strvarsoflist;
MACRO_DLL const char* GetStrItemOfList(const char *sz_arr_name, int ix) {
	try {
		string arr_name = string(sz_arr_name);
		sol::object tbl = lua[arr_name];
		sol::type t = tbl.get_type();
		// �{���Ƀe�[�u���ł���΁c
		if (t == sol::type::table) {
			sol::object value = lua[arr_name][ix];
			// ���̂܂ܕԂ��ƁA�G�ۂ��|�C���^�ł��������Ă��炸���ł���̂ŁAstatic����ɕۑ����Ă����B
			strvarsoflist = value.as<std::string>();
			// �ۑ����Ă�����̃|�C���^��Ԃ��K�v������B
			return strvarsoflist.data();
		}
		return "";
	}
	catch (std::exception& e) {
		lua_OutputDebugStream("%s\n", e.what());
		return "";
	}
}

MACRO_DLL int SetStrItemOfList(const char *sz_arr_name, int ix, char *value) {
	try {
		string arr_name = string(sz_arr_name);
		sol::object tbl = lua[arr_name];
		sol::type t = tbl.get_type();
		// �{���Ƀe�[�u���ł���΁c
		if (t == sol::type::table) {
			lua[arr_name][ix] = string(value);
			return TRUE;
		}
		return FALSE;
	}
	catch (std::exception& e) {
		lua_OutputDebugStream("%s\n", e.what());
		return FALSE;
	}
}


MACRO_DLL int GetNumItemOfDict(const char *sz_arr_name, const char *sz_key_name) {
	try {
		string arr_name = string(sz_arr_name);
		string key_name = string(sz_key_name);
		sol::object tbl = lua[arr_name];
		sol::type t = tbl.get_type();
		// �{���Ƀe�[�u���ł���΁c
		if (t == sol::type::table) {
			sol::object value = lua[arr_name][key_name];
			return value.as<int>();
		}
		return 0;
	}
	catch (std::exception& e) {
		lua_OutputDebugStream("%s\n", e.what());
		return 0;
	}
}

MACRO_DLL int SetNumItemOfDict(const char *sz_arr_name, const char *sz_key_name, int value) {
	try {
		string arr_name = string(sz_arr_name);
		string key_name = string(sz_key_name);
		sol::object tbl = lua[arr_name];
		sol::type t = tbl.get_type();
		// �{���Ƀe�[�u���ł���΁c
		if (t == sol::type::table) {
			lua[arr_name][key_name] = value;
			return TRUE;
		}
		return FALSE;
	}
	catch (std::exception& e) {
		lua_OutputDebugStream("%s\n", e.what());
		return FALSE;
	}
}


string strvarsofdict;
MACRO_DLL const char* GetStrItemOfDict(const char*sz_arr_name, const char* sz_key_name) {
	try {
		string arr_name = string(sz_arr_name);
		string key_name = string(sz_key_name);
		sol::object tbl = lua[arr_name];
		sol::type t = tbl.get_type();
		// �{���Ƀe�[�u���ł���΁c
		if (t == sol::type::table) {
			sol::object value = lua[arr_name][key_name];
			// ���̂܂ܕԂ��ƁA�G�ۂ��|�C���^�ł��������Ă��炸���ł���̂ŁAstatic����ɕۑ����Ă����B
			strvarsofdict = value.as<std::string>();
			// �ۑ����Ă�����̃|�C���^��Ԃ��K�v������B
			return strvarsofdict.data();
		}
		return "";
	}
	catch (std::exception& e) {
		lua_OutputDebugStream("%s\n", e.what());
		return "";
	}
}

MACRO_DLL int SetStrItemOfDict(const char*sz_arr_name, const char* sz_key_name, char *value) {
	try {
		string arr_name = string(sz_arr_name);
		string key_name = string(sz_key_name);
		sol::object tbl = lua[arr_name];
		sol::type t = tbl.get_type();
		// �{���Ƀe�[�u���ł���΁c
		if (t == sol::type::table) {
			lua[arr_name][key_name] = string(value);
			return TRUE;
		}
		return FALSE;
	}
	catch (std::exception& e) {
		lua_OutputDebugStream("%s\n", e.what());
		return FALSE;
	}
}

MACRO_DLL int GetLenOfList(const char*sz_arr_name) {
	try {
		string arr_name = string(sz_arr_name);
		sol::object tbl = lua[arr_name];
		sol::type t = tbl.get_type();

		// �{���Ƀe�[�u���ł���΁c
		if (t == sol::type::table) {
			sol::table soltbl = tbl;
			return soltbl.size();
		}
		return 0;
	}
	catch (std::exception& e) {
		lua_OutputDebugStream("%s\n", e.what());
		return 0;
	}
}



// printf�`���Ɠ��l�̌`���ŁAlua�̋L�q�����s���邱�Ƃ��ł���B
MACRO_DLL int DoString(const char *expression) {

	try {
		lua.script(expression);
		return TRUE;
	} catch(std::exception& e) {
		lua_OutputDebugStream("%s\n", e.what());
		return FALSE;
	}
}

// printf�`���Ɠ��l�̌`���ŁAlua�̋L�q�����s���邱�Ƃ��ł���B
MACRO_DLL int DoFile(const char *filename) {

	try {
		lua.script_file(filename);
		return TRUE;
	}
	catch (std::exception& e) {
		lua_OutputDebugStream("%s\n", e.what());
		return FALSE;
	}
}