#pragma once

extern void lua_OutputDebugStream(const char *format, ...);
