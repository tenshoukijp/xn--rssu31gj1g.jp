#pragma once


bool IsHandCursor();
