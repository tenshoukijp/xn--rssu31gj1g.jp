
#include <windows.h>
#include <process.h>
#include <stdio.h>
#include <tchar.h>
#include <string>
#include <commctrl.h>

using namespace std;

extern void OutputDebugStream(const wchar_t *format, ...);
extern void CreateHmStatusBarForm(HWND hWnd, System::String^ target);
extern void UpdateHmStatusBarForm();
extern void DestroyHmStatusBarForm();



HWND hmWndHandle = NULL;


wstring GetStatusBarText(HWND hStatusWndHandle) {
	/*
	LRESULT lLen = SendMessage(hStatusWndHandle, SB_GETTEXTLENGTH, 0, 0);
	if (!lLen) {
		OutputDebugStream(L"����");
		return L"";
	}
	if (lLen >=1024) {
		OutputDebugStream(L"������");
		return L"";
	}
	*/

	wchar_t szBuffer[4096] = L"";
	LRESULT lPart = SendMessage(hStatusWndHandle, SB_GETTEXT, 0, (LPARAM)szBuffer);
	szBuffer[4095] = NULL;

	return wstring(szBuffer);
}

wstring previousStatusBarText = L"";


void OnStatusBar_TextChanged(wstring text, HWND hWnd) {

	OutputDebugStream(text.c_str());

	if (text.length() > 0) {
		CreateHmStatusBarForm(hWnd, gcnew System::String(text.c_str()));
	}
	else {
		DestroyHmStatusBarForm();
	}
}



BOOL CALLBACK EnumChildProc(HWND hWnd, LPARAM lParam)
{
	wchar_t   szTitle[1024];
	char szClass[1024];

	GetWindowText(hWnd, szTitle, sizeof(szTitle));    // �L���v�V�����̎擾
	GetClassNameA(hWnd, szClass, sizeof(szClass));    // �N���X������̎擾 W�͖����̂Œ���

	if (strcmp(szClass, "msctls_statusbar32") == 0) {
		/*
		// �񋓃E�C���h�E�̕\��
		OutputDebugStream( L"%c %c %c %c %c %c [%-50s] [%s]\n",
			IsWindowUnicode(hWnd) ? 'U' : '_',              // Unicode�^�C�v
			IsWindowVisible(hWnd) ? 'V' : '_',              // �����
			IsWindowEnabled(hWnd) ? 'E' : '_',              // �L�����
			IsIconic(hWnd) ? 'I' : '_',              // �ŏ������
			IsZoomed(hWnd) ? 'Z' : '_',              // �ő剻���
			IsWindow(hWnd) ? 'W' : '_',              // �E�C���h�E�L��
			szClass,                                        // �N���X������
			szTitle);                                      // �L���v�V����
		*/

		wstring curStatsuBarText = GetStatusBarText(hWnd);

		
		// ���`��A�������Ȃ��˂��c
		HCURSOR hCursor = GetCursor();
		OutputDebugStream(L"%d", hCursor);
		if (hCursor == LoadCursor(NULL, IDC_IBEAM)) {
			// OutputDebugStream(L"BEAM2\n");
		}
		else {
			// OutputDebugStream(L"OTHER2\n");
		}
		hCursor = LoadCursor(NULL, IDC_WAIT);     // �����v�J�[�\��


		// OutputDebugStream(curStatsuBarText.c_str());
		if (previousStatusBarText != curStatsuBarText) {
			OnStatusBar_TextChanged(curStatsuBarText, hWnd);
			previousStatusBarText = curStatsuBarText;
		}
		else {
			UpdateHmStatusBarForm();
		}



	}


	return TRUE;
}

const int iThreadInterval = 300;

//�X���b�h�֐�
bool beExitThreadCheckStatusBar = false; // �X���b�h���甲����ׂ�
unsigned __stdcall ThreadCheckStatusBar(void *p)
{
	while(TRUE) {
		if (beExitThreadCheckStatusBar) {
			// OutputDebugStream( L"BREAK\n" );
			break;
		}
		// OutputDebugStream( L"TICK\n" );
		EnumChildWindows(hmWndHandle, EnumChildProc, (LPARAM)NULL);
		Sleep(iThreadInterval);
	}
	return 0;
}

HANDLE hThread = NULL;

extern "C" __declspec(dllexport) intptr_t SetHidemaruHandle(HWND pHmWndHandle) {
	hmWndHandle = pHmWndHandle;

	if (hThread == NULL) {
		hThread = (HANDLE)_beginthreadex(NULL, 0, ThreadCheckStatusBar, NULL, 0, NULL);
	}

	return TRUE;
}

extern "C" __declspec(dllexport) intptr_t DllDetachFunc_After_Hm866() {
	beExitThreadCheckStatusBar = true;
	WaitForSingleObject(hThread, iThreadInterval * 2); // �ň��ł��Q�{�܂�
	CloseHandle(hThread);

	DestroyHmStatusBarForm();

	// �X���b�h�̃X�g�b�v
	return TRUE;
}

