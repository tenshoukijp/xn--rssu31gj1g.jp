#pragma once

#include <windows.h>

extern void CreateHmStatusBarForm(HWND hWnd, System::String^ target);
extern void UpdateHmStatusBarForm();
extern void DestroyHmStatusBarForm();
