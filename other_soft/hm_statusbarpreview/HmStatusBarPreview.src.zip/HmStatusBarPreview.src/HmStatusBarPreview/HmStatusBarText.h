#pragma once

#include <windows.h>
#include <string>
using namespace std;


void OnCallBacke_StatusBar(HWND hWnd);

wstring GetStatusBarText(HWND hStatusWndHandle);
void ClearStatusBarCache();


void OnStatusBar_TextChanged(wstring text, HWND hWnd);

