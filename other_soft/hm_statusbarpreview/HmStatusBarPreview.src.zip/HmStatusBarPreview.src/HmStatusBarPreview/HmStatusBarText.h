#pragma once

#include <windows.h>
#include <string>
using namespace std;

namespace HmStatusBar {
	void OnCallBack(HWND hWnd);
	void ClearCache();
}
