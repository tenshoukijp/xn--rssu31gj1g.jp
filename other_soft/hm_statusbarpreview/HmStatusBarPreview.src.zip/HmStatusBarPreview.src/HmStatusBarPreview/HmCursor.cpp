#include <windows.h>
#include "OutputDebugStream.h"

bool IsHandCursor() {


	HINSTANCE hInstance = (HINSTANCE)GetModuleHandle(NULL);

	// ���`��A�������Ȃ��˂��c
	HCURSOR hCursor = GetCursor();

	PICONINFO piconinfo;

	GetIconInfo(hCursor, piconinfo);

	if (hCursor == LoadCursor(hInstance, IDC_HAND)) {
		OutputDebugStream(L"HAND\n");
		return true;
	}
	else {
		OutputDebugStream(L"OTHER\n");
		return false;
	}
}
