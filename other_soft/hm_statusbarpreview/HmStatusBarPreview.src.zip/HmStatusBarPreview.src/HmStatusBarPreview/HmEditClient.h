#pragma once


extern HWND hHm32Client; // �G�f�B�g

bool IsMousePointOutofWindowRange(HWND hWnd);

void OnCallBack_EditClient(HWND hWnd);
