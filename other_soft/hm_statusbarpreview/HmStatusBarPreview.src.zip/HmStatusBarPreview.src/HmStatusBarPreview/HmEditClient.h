#pragma once


extern HWND hHm32Client; // �G�f�B�g

namespace HidemaruEditClient {
	bool IsInMouse(HWND hWnd);

	void OnCallBack(HWND hWnd);
}
