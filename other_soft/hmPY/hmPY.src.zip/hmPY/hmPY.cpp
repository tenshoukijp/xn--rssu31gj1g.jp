#include <windows.h>
#include <string>
#include <map>

#include "outputdebugstream.h"
#include "string_converter.h"

using namespace std;

using namespace System;
using namespace System::Collections::Generic;

using namespace System::Windows::Forms;

using namespace IronPython::Hosting;
using namespace Microsoft::Scripting::Hosting;






ref class G {
public:
	static ScriptEngine^ pe;
	static ScriptScope^ ss;
};


int iPYCreateScope() {
	// �܂��G���W��������Ă��Ȃ����
	if (G::pe == nullptr || G::ss == nullptr) {
		try {
			//�G���W���쐬
			G::pe = Python::CreateEngine();
			G::ss = G::pe->CreateScope();
			return 1;
		}
		catch (Exception^ e) {
			OutputDebugStream(e->Message);
			return 0;
		}

	}
	return 1;
}


int iPYGetNumVar(const char *sz_var_name) {
	if (iPYCreateScope() == 0) {
		return 0;
	}

	try {
		String^ mng_var_name = gcnew String(sz_var_name);
		auto var = G::ss->GetVariable<double>(mng_var_name);
		return (int)var;
	}
	catch (Exception^ e) {
		OutputDebugStream(e->Message);
	}
	return 0;
}

int iPYSetNumVar(const char *sz_var_name, int value) {
	if (iPYCreateScope() == 0) {
		return 0;
	}

	try {
		String^ mng_var_name = gcnew String(sz_var_name);
		G::ss->SetVariable(mng_var_name, value);
		return 1;
	}
	catch (Exception^ e) {
		OutputDebugStream(e->Message);
	}
	return 0;
}


string strvars;
const char* iPYGetStrVar(const char *sz_var_name) {
	if (iPYCreateScope() == 0) {
		return "";
	}

	try {
		String^ mng_var_name = gcnew String(sz_var_name);
		string std_var_name = string(sz_var_name);
		auto var = G::ss->GetVariable(mng_var_name);
		strvars = String_to_string(var->ToString());
		return strvars.data();
	}
	catch (Exception^ e) {
		OutputDebugStream(e->Message);
	}
	return "";
}

int iPYSetStrVar(const char *sz_var_name, const char *value) {
	if (iPYCreateScope() == 0) {
		return 0;
	}

	try {
		String^ mng_var_name = gcnew String(sz_var_name);
		String^ mng_value = gcnew String(value);
		G::ss->SetVariable(mng_var_name, mng_value);
		return 1;
	}
	catch (Exception^ e) {
		OutputDebugStream(e->Message);
	}
	return 0;
}

/*
int iPYGetNumItemOfList(const char *sz_var_name, const int index) {
	ENGINE_CHECK();

	try {
		String^ mng_var_name = gcnew String(sz_var_name);
		Object^ arr = G::ss->GetVariable(mng_var_name);

		try {
			// ���X�g�Ȃ�΁c
			if (arr->GetType()->ToString() == "IronPython.Runtime.List") {
				auto result = G::ss->GetVariable<IronPython::Runtime::List^>(mng_var_name);

				int len = result->Count; // �z��̗v�f

				// ix���}�C�i�X�Ȃ�A�������炻�̐��l�����������̂Ƃ���B
				int ix = index;
				if (ix < 0) { ix = len - ix; }

				// ������T��
				int i = 0;
				for each (auto var in result) {
					if (ix == i) {
						return (int)var;
					}
					i++;
				}

			// �^�v���Ȃ�΁c
			} else if (arr->GetType()->ToString() == "IronPython.Runtime.PythonTuple") {
				auto result = G::ss->GetVariable<IronPython::Runtime::PythonTuple^>(mng_var_name);

				// ix���}�C�i�X�Ȃ�A�������炻�̐��l�����������̂Ƃ���B
				int ix = index;

				// ������T��
				int i = 0;
				for each (auto varref in result) {
					if (ix == i) {
						return (int)varref;
					}
					i++;
				}
			}
		}
		catch (Exception^ e) {
			OutputDebugStream(e->Message);
		}
	}
	catch (Exception^ e) {
		OutputDebugStream(e->Message);
	}
	return 0;
}

int iPYSetNumItemOfList(const char *sz_var_name, const int index, const int value) {
	ENGINE_CHECK();

	try {
		String^ mng_var_name = gcnew String(sz_var_name);
		Object^ arr = G::ss->GetVariable(mng_var_name);

		try {
			// ���X�g�Ȃ�΁c
			if (arr->GetType()->ToString() == "IronPython.Runtime.List") {
				auto% result = G::ss->GetVariable<IronPython::Runtime::List^>(mng_var_name);

				int len = result->Count; // �z��̗v�f

				// ix���}�C�i�X�Ȃ�A�������炻�̐��l�����������̂Ƃ���B
				int ix = index;
				if (ix < 0) { ix = len - ix; }

				// ������T��
				int i = 0;
				for each (auto% varref in result) {
					if (ix == i) {
						varref = value;
					}
					i++;
				}
			}
		}
		catch (Exception^ e) {
			OutputDebugStream(e->Message);
		}
	}
	catch (Exception^ e) {
		OutputDebugStream(e->Message);
	}
	return 0;
}
*/

int iPYDoString(const char *szcommand) {
	if (iPYCreateScope() == 0) {
		return 0;
	}

	try {
		String^ szexpression = gcnew String(szcommand);
		G::pe->Execute(szexpression, G::ss);
		return 1;
	}
	catch (Exception^ e) {
		OutputDebugStream(e->Message);
		return 0;
	}
}


int iPYDeleteScope(void *param) {
	G::ss = nullptr;
	G::pe = nullptr;
	return 1;
}