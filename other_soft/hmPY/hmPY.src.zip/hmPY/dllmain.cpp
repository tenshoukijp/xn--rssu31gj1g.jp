#include <windows.h>

extern int iPYGetNumVar(const char *sz_var_name);
extern const char* iPYGetStrVar(const char *sz_var_name);
extern int iPYSetNumVar(const char *sz_var_name, int value);
extern int iPYSetStrVar(const char *sz_var_name, const char *value);
/*
extern int iPYGetNumItemOfList(const char *sz_arr_name, const int index);
extern int iPYSetNumItemOfList(const char *sz_arr_name, const int index, const int value);
*/

extern int iPYDoString(const char *szcommand);


extern "C" __declspec(dllexport) int GetNumVar(const char *sz_var_name) {
	return iPYGetNumVar(sz_var_name);
}

extern "C" __declspec(dllexport) const char * GetStrVar(const char *sz_var_name) {
	return iPYGetStrVar(sz_var_name);
}

extern "C" __declspec(dllexport) int SetNumVar(const char *sz_var_name, int value) {
	return iPYSetNumVar(sz_var_name, value);
}

extern "C" __declspec(dllexport) int SetStrVar(const char *sz_var_name, const char *value) {
	return iPYSetStrVar(sz_var_name, value);
}

/*
extern "C" __declspec(dllexport) int GetNumItemOfArr(const char *sz_var_name, const int index) {
	return iPYGetNumItemOfList(sz_var_name, index);
}

extern "C" __declspec(dllexport) int SetNumItemOfArr(const char *sz_var_name, const int index, const int value) {
	return iPYSetNumItemOfList(sz_var_name, index, value);
}
*/
extern "C" __declspec(dllexport) int DoString(char *szcommand) {
	return iPYDoString(szcommand);
}

