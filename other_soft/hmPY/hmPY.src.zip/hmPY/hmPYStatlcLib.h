using namespace System;
using namespace System::Collections::Generic;

using namespace System::Windows::Forms;

using namespace IronPython::Hosting;
using namespace Microsoft::Scripting::Hosting;



public ref class hmPYStaticLib
{
public:
	static ScriptEngine ^pe;
	static ScriptScope ^ss;

	static void OutputDebugStream(String ^error);
	static int iPYCreateScope();
	static int iPYGetNumVar(String ^mng_var_name);
	static int iPYSetNumVar(String ^mng_var_name, int value);
	static String ^iPYGetStrVar(String ^mng_var_name);
	static int iPYSetStrVar(String ^mng_var_name, String ^mng_value);
	static int iPYGetNumItemOfList(String ^mng_var_name, int index);
	static int iPYSetNumItemOfList(String ^mng_var_name, int index, int value);
	static int iPYDoString(String ^szcommand);
};


