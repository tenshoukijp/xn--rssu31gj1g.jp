#pragma once

using namespace System;

// dynamic�^�𗘗p���Ȃ����́Bdynamic���Ăяo�������B�������邱�ƂŁAC++�ƃ����N���邱�Ƃ��ł���(���\�b�h�̌������킹�邱�Ƃ��o����)
public ref class IV8StaticLib
{
public:
	static void OutputDebugStream(String^ error);

	static IntPtr SetDebuggingPort(IntPtr port);

	static IntPtr CreateScope();

	static IntPtr BindDllHandle(IntPtr dll);

	static void SetCodePage(IntPtr cp);

	static IntPtr SetTmpVar(Object^ value);

	static Object^ PopTmpVar();

	//-----------------------------------------------------------------
	static IntPtr GetNumVar(String^ mng_var_name);

	static IntPtr SetNumVar(String^ mng_var_name, IntPtr value);

	static String^ GetStrVar(String^ mng_var_name);

	static IntPtr SetStrVar(String^ mng_var_name, String^ value);
	//-----------------------------------------------------------------

	//-----------------------------------------------------------------
	static IntPtr GetNumItemOfList(String^ mng_arr_name, IntPtr index);

	static IntPtr SetNumItemOfList(String^ mng_arr_name, IntPtr index, IntPtr value);

	static String^ GetStrItemOfList(String^ mng_arr_name, IntPtr index);

	static IntPtr SetStrItemOfList(String^ mng_arr_name, IntPtr index, String^ value);
	//-----------------------------------------------------------------

	//-----------------------------------------------------------------
	static IntPtr GetNumItemOfDict(String^ mng_arr_name, String^ key);

	static IntPtr SetNumItemOfDict(String^ mng_arr_name, String^ key, IntPtr value);

	static String^ GetStrItemOfDict(String^ mng_arr_name, String^ key);

	static IntPtr SetStrItemOfDict(String^ mng_arr_name, String^ key, String^ value);
	//-----------------------------------------------------------------


	static IntPtr DoString(String^ expression);

	static IntPtr DoFile(String^ filename);

	static IntPtr DestroyScope();

};