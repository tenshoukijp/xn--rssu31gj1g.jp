#pragma once

#include <windows.h>
#include "tstring.h"

using namespace std;

extern TCHAR szCurrentFileOnCallSetHidemaruHandle[MAX_PATH * 2];

extern TCHAR *GetCurrentFileName();
