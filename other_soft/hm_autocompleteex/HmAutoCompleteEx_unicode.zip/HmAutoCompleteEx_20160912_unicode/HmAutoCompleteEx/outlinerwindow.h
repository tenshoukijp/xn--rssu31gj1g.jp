#pragma once

#include <windows.h>

void AnalizeOutlinerListBox(HWND wnd);
