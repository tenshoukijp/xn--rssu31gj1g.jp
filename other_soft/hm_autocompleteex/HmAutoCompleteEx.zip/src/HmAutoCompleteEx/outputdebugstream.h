#pragma once

extern void OutputDebugStream(const char *format, ...);
