#include <windows.h>

extern char szCurrentFileOnCallSetHidemaruHandle[MAX_PATH * 2];
