#include <windows.h>
#include <string>

using namespace std;

extern char szCurrentFileOnCallSetHidemaruHandle[MAX_PATH * 2];

extern char *GetCurrentFileName();
