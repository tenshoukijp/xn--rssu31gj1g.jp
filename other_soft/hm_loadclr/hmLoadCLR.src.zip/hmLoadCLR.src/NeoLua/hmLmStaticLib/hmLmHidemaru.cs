﻿using System;
using System.Runtime.InteropServices;

using Neo.IronLua;


// アンマネージドライブラリの遅延での読み込み。C++のLoadLibraryと同じことをするため
// これをする理由は、このhmPyとHideamru.exeが異なるディレクトリに存在する可能性があるため、
// C#風のDllImportは成立しないからだ。
internal class UnManagedDll : IDisposable
{
    [DllImport("kernel32")]
    static extern IntPtr LoadLibrary(string lpFileName);
    [DllImport("kernel32")]
    static extern IntPtr GetProcAddress(IntPtr hModule, string lpProcName);
    [DllImport("kernel32")]
    static extern bool FreeLibrary(IntPtr hModule);

    IntPtr moduleHandle;

    public UnManagedDll(string lpFileName)
    {
        moduleHandle = LoadLibrary(lpFileName);
    }

    public IntPtr ModuleHandle
    {
        get
        {
            return moduleHandle;
        }
    }

    public T GetProcDelegate<T>(string method) where T : class
    {
        IntPtr methodHandle = GetProcAddress(moduleHandle, method);
        T r = Marshal.GetDelegateForFunctionPointer(methodHandle, typeof(T)) as T;
        return r;
    }

    public void Dispose()
    {
        FreeLibrary(moduleHandle);
    }
}


// ★クラス実装内のメソッドの中でdynamic型を利用したもの。これを直接利用しないのは、内部でdynamic型を利用していると、クラスに自動的にメソッドが追加されてしまい、C++とはヘッダのメソッドの個数が合わなくなりリンクできなくなるため。
public partial class hmLmDynamicLib
{
    public class Hidemaru
    {
        public Hidemaru()
        {
            System.Diagnostics.FileVersionInfo vi = System.Diagnostics.FileVersionInfo.GetVersionInfo(strExecuteFullpath);
            _ver = 100 * vi.FileMajorPart + 10 * vi.FileMinorPart + 1 * vi.FileBuildPart + 0.01 * vi.FilePrivatePart;
            Macro.NumVar = new Macro.TMacroNumVar();
            Macro.StrVar = new Macro.TMacroStrVar();
        }
        delegate IntPtr TGetTotalTextUnicode();
        delegate IntPtr TGetLineTextUnicode(int nLineNo);
        delegate IntPtr TGetSelectedTextUnicode();
        delegate int TGetCursorPosUnicode(ref int pnLineNo, ref int pnColumn);
        delegate int TEvalMacro([MarshalAs(UnmanagedType.LPWStr)] String pwsz);
        delegate int TCheckQueueStatus();

        static TGetTotalTextUnicode pGetTotalTextUnicode;
        static TGetLineTextUnicode pGetLineTextUnicode;
        static TGetSelectedTextUnicode pGetSelectedTextUnicode;
        static TGetCursorPosUnicode pGetCursorPosUnicode;
        static TEvalMacro pEvalMacro;
        static TCheckQueueStatus pCheckQueueStatus;

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr GlobalLock(IntPtr hMem);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern int GlobalUnlock(IntPtr hMem);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr GlobalFree(IntPtr hMem);

        public static void debuginfo(Object expression)
        {
            OutputDebugStream(expression.ToString());
        }

        // バージョン。hm.versionのため。読み取り専用
        static double _ver;
        public static double version
        {
            get { return _ver; }
        }

        // 秀丸本体のexeを指すモジュールハンドル
        static UnManagedDll hmExeHandle;

        // 秀丸本体のExport関数を使えるようにポインタ設定。
        static void SetUnManagedDll()
        {
            // 初めての代入のみ
            if (hmExeHandle == null)
            {
                hmExeHandle = new UnManagedDll(strExecuteFullpath);

                if (version >= 866) // ver 8.6.6以上が対象
                {
                    pGetTotalTextUnicode = hmExeHandle.GetProcDelegate<TGetTotalTextUnicode>("Hidemaru_GetTotalTextUnicode");
                    pGetLineTextUnicode = hmExeHandle.GetProcDelegate<TGetLineTextUnicode>("Hidemaru_GetLineTextUnicode");
                    pGetSelectedTextUnicode = hmExeHandle.GetProcDelegate<TGetSelectedTextUnicode>("Hidemaru_GetSelectedTextUnicode");
                    pGetCursorPosUnicode = hmExeHandle.GetProcDelegate<TGetCursorPosUnicode>("Hidemaru_GetCursorPosUnicode");
                    pEvalMacro = hmExeHandle.GetProcDelegate<TEvalMacro>("Hidemaru_EvalMacro");
                    pCheckQueueStatus = hmExeHandle.GetProcDelegate<TCheckQueueStatus>("Hidemaru_CheckQueueStatus");
                }
            }
        }

        public class Edit
        {

            static Edit()
            {
                SetUnManagedDll();
            }
            /// <summary>
            ///  CursorPos
            /// </summary>
            public static LuaTable CursorPos
            {
                get
                {
                    return GetCursorPos();
                }
            }


            // columnやlinenoはエディタ的な座標である。
            private static LuaTable GetCursorPos()
            {
                if (version < 866)
                {
                    OutputDebugStream("このメソッドは秀丸エディタ v8.66以降で利用可能です。");
                    var t = new LuaTable();
                    t["column"] = 1;
                    t["lineno"] = 0;
                    return t;
                }

                int column = -1;
                int lineno = -1;
                pGetCursorPosUnicode(ref lineno, ref column);

                LuaTable p = new LuaTable();
                p["lineno"] = lineno;
                p["column"] = column;
                return p;
            }


            /// <summary>
            /// TotalText
            /// </summary>
            public static String TotalText
            {
                get
                {
                    return GetTotalText();
                }
                set
                {
                    SetTotalText(value);
                }
            }

            private static void SetTotalText(String value)
            {
                if (version < 866)
                {
                    OutputDebugStream("このメソッドは秀丸エディタ v8.66以降で利用可能です。");
                    return;
                }

                int dll = iDllBindHandle;

                if (dll == 0)
                {
                    throw new NullReferenceException(strDllFullPath + "をloaddllした際の束縛変数の値を特定できません");
                }

                // シンプルロードタイプであれば…
                if (dll == -1)
                {
                    SetStrVar("__tmp_set_str_var__", value);
                    String cmd_single = "selectall;\n" +
                    "insert dllfuncstrw( \"GetStrVar\", \"__tmp_set_str_var__\");\n";
                    Macro.Eval(cmd_single);
                    SetStrVar("__tmp_set_str_var__", null);
                }

                // マルチロードタイプであれば…
                else
                {
                    SetStrVar("__tmp_set_str_var__", value);
                    String cmd_multi = "selectall;\n" +
                    "insert dllfuncstrw( " + dll + ", \"GetStrVar\", \"__tmp_set_str_var__\");\n";
                    Macro.Eval(cmd_multi);
                    SetStrVar("__tmp_set_str_var__", null);
                }
            }


            // 途中でエラーが出るかもしれないので、相応しいUnlockやFreeが出来るように内部管理用
            private enum HGlobalStatus { None, Lock, Unlock, Free };

            // 現在の秀丸の編集中のテキスト全て。元が何の文字コードでも関係なく秀丸がwchar_tのユニコードで返してくれるので、
            // String^型に入れておけば良い。
            public static String GetTotalText()
            {
                if (version < 866)
                {
                    OutputDebugStream("このメソッドは秀丸エディタ v8.66以降で利用可能です。");
                    return "";
                }

                String curstr = "";
                IntPtr hGlobal = pGetTotalTextUnicode();
                HGlobalStatus hgs = HGlobalStatus.None;
                if (hGlobal != null)
                {
                    try
                    {
                        IntPtr ret = GlobalLock(hGlobal);
                        hgs = HGlobalStatus.Lock;
                        curstr = Marshal.PtrToStringUni(ret);
                        GlobalUnlock(hGlobal);
                        hgs = HGlobalStatus.Unlock;
                        GlobalFree(hGlobal);
                        hgs = HGlobalStatus.Free;
                    }
                    catch (Exception e)
                    {
                        OutputDebugStream(e.Message);
                    }
                    finally
                    {
                        switch (hgs)
                        {
                            // ロックだけ成功した
                            case HGlobalStatus.Lock:
                                {
                                    GlobalUnlock(hGlobal);
                                    GlobalFree(hGlobal);
                                    break;
                                }
                            // アンロックまで成功した
                            case HGlobalStatus.Unlock:
                                {
                                    GlobalFree(hGlobal);
                                    break;
                                }
                            // フリーまで成功した
                            case HGlobalStatus.Free:
                                {
                                    break;
                                }
                        }
                    }
                }
                return curstr;
            }


            /// <summary>
            ///  SelecetdText
            /// </summary>
            public static String SelectedText
            {
                get
                {
                    return GetSelectedText();
                }
                set
                {
                    SetSelectedText(value);
                }
            }

            // 現在の秀丸の選択中のテキスト。元が何の文字コードでも関係なく秀丸がwchar_tのユニコードで返してくれるので、
            // String^型に入れておけば良い。
            public static String GetSelectedText()
            {
                if (version < 866)
                {
                    OutputDebugStream("このメソッドは秀丸エディタ v8.66以降で利用可能です。");
                    return "";
                }

                String curstr = "";
                IntPtr hGlobal = pGetSelectedTextUnicode();
                HGlobalStatus hgs = HGlobalStatus.None;
                if (hGlobal != null)
                {
                    try
                    {
                        IntPtr ret = GlobalLock(hGlobal);
                        hgs = HGlobalStatus.Lock;
                        curstr = Marshal.PtrToStringUni(ret);
                        GlobalUnlock(hGlobal);
                        hgs = HGlobalStatus.Unlock;
                        GlobalFree(hGlobal);
                        hgs = HGlobalStatus.Free;
                    }
                    catch (Exception e)
                    {
                        OutputDebugStream(e.Message);
                    }
                    finally
                    {
                        switch (hgs)
                        {
                            // ロックだけ成功した
                            case HGlobalStatus.Lock:
                                {
                                    GlobalUnlock(hGlobal);
                                    GlobalFree(hGlobal);
                                    break;
                                }
                            // アンロックまで成功した
                            case HGlobalStatus.Unlock:
                                {
                                    GlobalFree(hGlobal);
                                    break;
                                }
                            // フリーまで成功した
                            case HGlobalStatus.Free:
                                {
                                    break;
                                }
                        }
                    }
                }

                if (curstr == null)
                {
                    curstr = "";
                }
                return curstr;
            }


            private static void SetSelectedText(String value)
            {
                if (version < 866)
                {
                    OutputDebugStream("このメソッドは秀丸エディタ v8.66以降で利用可能です。");
                    return;
                }

                int dll = iDllBindHandle;

                if (dll == 0)
                {
                    throw new NullReferenceException(strDllFullPath + "をloaddllした際の束縛変数の値を特定できません");
                }

                // シンプルロードタイプであれば…
                if (dll == -1)
                {
                    SetStrVar("__tmp_set_str_var__", value);
                    String cmd_single = "if (selecting) {\n" +
                    "insert dllfuncstrw( \"GetStrVar\", \"__tmp_set_str_var__\");\n" +
                    "}\n";
                    Macro.Eval(cmd_single);
                    SetStrVar("__tmp_set_str_var__", null);
                }

                // マルチロードタイプであれば…
                else
                {
                    SetStrVar("__tmp_set_str_var__", value);
                    String cmd_multi = "if (selecting) {\n" +
                    "insert dllfuncstrw( " + dll + ", \"GetStrVar\", \"__tmp_set_str_var__\");\n" +
                    "}\n";
                    Macro.Eval(cmd_multi);
                    SetStrVar("__tmp_set_str_var__", null);
                }
            }

            /// <summary>
            /// LineText
            /// </summary>
            public static String LineText
            {
                get
                {
                    return GetLineText();
                }
            }

            // 現在の秀丸の編集中のテキストで、カーソルがある行だけのテキスト。
            // 元が何の文字コードでも関係なく秀丸がwchar_tのユニコードで返してくれるので、
            // String^型に入れておけば良い。
            public static String GetLineText()
            {
                if (version < 866)
                {
                    OutputDebugStream("このメソッドは秀丸エディタ v8.66以降で利用可能です。");
                    return "";
                }

                LuaTable p = GetCursorPos();

                String curstr = "";
                IntPtr hGlobal = pGetLineTextUnicode((int)p["lineno"]);
                HGlobalStatus hgs = HGlobalStatus.None;
                if (hGlobal != null)
                {
                    try
                    {
                        IntPtr ret = GlobalLock(hGlobal);
                        hgs = HGlobalStatus.Lock;
                        curstr = Marshal.PtrToStringUni(ret);
                        GlobalUnlock(hGlobal);
                        hgs = HGlobalStatus.Unlock;
                        GlobalFree(hGlobal);
                        hgs = HGlobalStatus.Free;
                    }
                    catch (Exception e)
                    {
                        OutputDebugStream(e.Message);
                    }
                    finally
                    {
                        switch (hgs)
                        {
                            // ロックだけ成功した
                            case HGlobalStatus.Lock:
                                {
                                    GlobalUnlock(hGlobal);
                                    GlobalFree(hGlobal);
                                    break;
                                }
                            // アンロックまで成功した
                            case HGlobalStatus.Unlock:
                                {
                                    GlobalFree(hGlobal);
                                    break;
                                }
                            // フリーまで成功した
                            case HGlobalStatus.Free:
                                {
                                    break;
                                }
                        }
                    }
                }
                return curstr;
            }
        }

        public class Macro
        {
            static Macro()
            {
                SetUnManagedDll();
            }

            public static int Eval(String cmd)
            {
                if (version < 866)
                {
                    OutputDebugStream("このメソッドは秀丸エディタ v8.66以降で利用可能です。");
                    return 0;
                }

                int ret = 0;
                try
                {
                    ret = pEvalMacro(cmd);
                }
                catch (Exception e)
                {
                    OutputDebugStream(e.Message);
                }
                return ret;
            }

            // マクロ文字列の実行。複数行を一気に実行可能
            public static TMacroNumVar NumVar;
            public class TMacroNumVar
            {
                public TMacroNumVar() { }
                public int this[String var_name]
                {
                    get
                    {
                        if (version < 866)
                        {
                            OutputDebugStream("このメソッドは秀丸エディタ v8.66以降で利用可能です。");
                            return 0;
                        }

                        tmpNumVar = 0;

                        int dll = iDllBindHandle;

                        if (dll == 0)
                        {
                            throw new NullReferenceException(strDllFullPath + "をloaddllした際の束縛変数の値を特定できません");
                        }

                        // シンプルロードタイプであれば…
                        if (dll == -1)
                        {
                            String cmd_single = "" +
                              "##_tmp_clr_dll_id_ret = dllfuncw( \"SetTmpNumVar\", " + var_name + ");\n" +
                              "##_tmp_clr_dll_id_ret = 0;\n";
                            Eval(cmd_single);
                        }

                        // マルチロードタイプであれば…
                        else
                        {
                            String cmd_multi = "" +
                              "##_tmp_clr_dll_id_ret = dllfuncw( " + dll + ", \"SetTmpNumVar\", " + var_name + ");\n" +
                              "##_tmp_clr_dll_id_ret = 0;\n";
                            Eval(cmd_multi);
                        }

                        int tmp = tmpNumVar;
                        tmpNumVar = 0;
                        return tmp;
                    }

                    set
                    {
                        if (version < 866)
                        {
                            OutputDebugStream("このメソッドは秀丸エディタ v8.66以降で利用可能です。");
                            return;
                        }

                        tmpNumVar = 0;

                        int dll = iDllBindHandle;

                        if (dll == 0)
                        {
                            throw new NullReferenceException(strDllFullPath + "をloaddllした際の束縛変数の値を特定できません");
                        }


                        // シンプルロードタイプであれば…
                        if (dll == -1)
                        {
                            SetNumVar("__tmp_set_num_var__", value);
                            String cmd_single = "" +
                              var_name + " = dllfuncw( \"GetNumVar\", \"__tmp_set_num_var__\");\n";
                            Eval(cmd_single);
                            SetNumVar("__tmp_set_num_var__", 0);
                        }

                        // マルチロードタイプであれば…
                        else
                        {
                            SetNumVar("__tmp_set_str_var__", value);
                            String cmd_multi = "" +
                              var_name + " = dllfuncw( " + dll + ", \"GetNumVar\", \"__tmp_set_str_var__\");\n";
                            Eval(cmd_multi);
                            SetNumVar("__tmp_set_str_var__", 0);
                        }
                    }

                }
            }

            public static TMacroStrVar StrVar;
            public class TMacroStrVar
            {
                public TMacroStrVar() { }
                public String this[String var_name]
                {
                    get
                    {
                        if (version < 866)
                        {
                            OutputDebugStream("このメソッドは秀丸エディタ v8.66以降で利用可能です。");
                            return "";
                        }

                        tmpStrVar = "";

                        int dll = iDllBindHandle;

                        if (dll == 0)
                        {
                            throw new NullReferenceException(strDllFullPath + "をloaddllした際の束縛変数の値を特定できません");
                        }

                        // シンプルロードタイプであれば…
                        if (dll == -1)
                        {
                            String cmd_single = "" +
                              "##_tmp_clr_dll_id_ret = dllfuncw( \"SetTmpStrVar\", " + var_name + ");\n" +
                              "##_tmp_clr_dll_id_ret = 0;\n";
                            Eval(cmd_single);
                        }

                        // マルチロードタイプであれば…
                        else
                        {
                            String cmd_multi = "" +
                              "##_tmp_clr_dll_id_ret = dllfuncw( " + dll + ", \"SetTmpStrVar\", " + var_name + ");\n" +
                              "##_tmp_clr_dll_id_ret = 0;\n";
                            Eval(cmd_multi);
                        }

                        String tmp = tmpStrVar + "";
                        tmpStrVar = "";
                        return tmp;
                    }

                    set
                    {
                        if (version < 866)
                        {
                            OutputDebugStream("このメソッドは秀丸エディタ v8.66以降で利用可能です。");
                            return;
                        }

                        tmpStrVar = "";

                        int dll = iDllBindHandle;

                        if (dll == 0)
                        {
                            throw new NullReferenceException(strDllFullPath + "をloaddllした際の束縛変数の値を特定できません");
                        }



                        // シンプルロードタイプであれば…
                        if (dll == -1)
                        {
                            SetStrVar("__tmp_set_str_var__", value);
                            String cmd_single = "" +
                              var_name + " = dllfuncstrw( \"GetStrVar\", \"__tmp_set_str_var__\");\n";
                            Eval(cmd_single);
                            SetStrVar("__tmp_set_str_var__", null);
                        }

                        // マルチロードタイプであれば…
                        else
                        {
                            SetStrVar("__tmp_set_str_var__", value);
                            String cmd_multi = "" +
                              var_name + " = dllfuncstrw( " + dll + ", \"GetStrVar\", \"__tmp_set_str_var__\");\n";
                            Eval(cmd_multi);
                            SetStrVar("__tmp_set_str_var__", null);
                        }
                    }

                }
            }
        }

    }
}
