#pragma once

#include <tchar.h>
#include <cstdint>

#define MACRO_DLL extern "C" __declspec(dllexport)


#define intHM_t intptr_t
