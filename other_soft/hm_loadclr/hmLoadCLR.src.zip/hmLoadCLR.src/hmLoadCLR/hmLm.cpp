#include <windows.h>
#include <string>

#include "string_converter.h"
#include "hmLmStatlcLib.h"

#define MACRO_DLL extern "C" __declspec(dllexport)

using namespace std;
using namespace System;

bool isSetModuleFullPath = false;
void SetModuleFullPath() {
	if (!isSetModuleFullPath) {
		TCHAR szHidemaruFullPath[MAX_PATH] = _T("");
		GetModuleFileName(NULL, szHidemaruFullPath, _countof(szHidemaruFullPath));
		ILmStaticLib::SetModuleFullPath(gcnew String(szHidemaruFullPath));
		isSetModuleFullPath = true;
	}
}

MACRO_DLL int BindDllHandle(int dll) {
	SetModuleFullPath();
	ILmStaticLib::BindDllHandle(dll);
	return dll;
}

MACRO_DLL int SetCodePage(int cp) {
	SetModuleFullPath();
	ILmStaticLib::SetCodePage(cp);
	return TRUE;
}

//------------------------------------------------------------------------------------
MACRO_DLL int GetNumVar(const TCHAR *sz_var_name) {
	SetModuleFullPath();
	return ILmStaticLib::GetNumVar(gcnew String(sz_var_name));
}

MACRO_DLL int SetNumVar(const TCHAR *sz_var_name, int value) {
	SetModuleFullPath();
	return ILmStaticLib::SetNumVar(gcnew String(sz_var_name), value);
}

MACRO_DLL int SetTmpNumVar(int value) {
	SetModuleFullPath();
	return ILmStaticLib::SetTmpNumVar(value);
}

// �G�ۂ̃L���b�V���̂���
static wstring strvars;
MACRO_DLL const TCHAR * GetStrVar(const TCHAR *sz_var_name) {
	SetModuleFullPath();
	auto var = ILmStaticLib::GetStrVar(gcnew String(sz_var_name));
	strvars = String_to_tstring(var->ToString());
	return strvars.data();
}

MACRO_DLL int SetStrVar(const TCHAR *sz_var_name, const TCHAR *value) {
	SetModuleFullPath();
	return ILmStaticLib::SetStrVar(gcnew String(sz_var_name), gcnew String(value));
}

MACRO_DLL int SetTmpStrVar(const TCHAR *value) {
	SetModuleFullPath();
	return ILmStaticLib::SetTmpStrVar(gcnew String(value));
}
//------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------
MACRO_DLL int GetNumItemOfList(const TCHAR *sz_arr_name, const int index) {
	SetModuleFullPath();
	return ILmStaticLib::GetNumItemOfList(gcnew String(sz_arr_name), index);
}

MACRO_DLL int SetNumItemOfList(const TCHAR *sz_arr_name, const int index, const int value) {
	SetModuleFullPath();
	return ILmStaticLib::SetNumItemOfList(gcnew String(sz_arr_name), index, value);
}

// �G�ۂ̃L���b�V���̂���
static wstring strvarsoflist;
MACRO_DLL const TCHAR * GetStrItemOfList(const TCHAR *sz_arr_name, const int index) {
	SetModuleFullPath();
	auto var = ILmStaticLib::GetStrItemOfList(gcnew String(sz_arr_name), index);
	strvarsoflist = String_to_tstring(var->ToString());
	return strvarsoflist.data();
}

MACRO_DLL int SetStrItemOfList(const TCHAR *sz_arr_name, const int index, const TCHAR *value) {
	SetModuleFullPath();
	return ILmStaticLib::SetStrItemOfList(gcnew String(sz_arr_name), index, gcnew String(value));
}
//------------------------------------------------------------------------------------



//------------------------------------------------------------------------------------
MACRO_DLL int GetNumItemOfDict(const TCHAR *sz_arr_name, const TCHAR *key) {
	SetModuleFullPath();
	return ILmStaticLib::GetNumItemOfDict(gcnew String(sz_arr_name), gcnew String(key));
}

MACRO_DLL int SetNumItemOfDict(const TCHAR *sz_arr_name, const TCHAR *key, const int value) {
	SetModuleFullPath();
	return ILmStaticLib::SetNumItemOfDict(gcnew String(sz_arr_name), gcnew String(key), value);
}

// �G�ۂ̃L���b�V���̂���

static wstring strvarsofdict;
MACRO_DLL const TCHAR * GetStrItemOfDict(const TCHAR *sz_arr_name, const TCHAR *key) {
	SetModuleFullPath();
	auto var = ILmStaticLib::GetStrItemOfDict(gcnew String(sz_arr_name), gcnew String(key));
	strvarsofdict = String_to_tstring(var->ToString());
	return strvarsofdict.data();
}

MACRO_DLL int SetStrItemOfDict(const TCHAR *sz_arr_name, const TCHAR *key, const TCHAR *value) {
	SetModuleFullPath();
	return ILmStaticLib::SetStrItemOfDict(gcnew String(sz_arr_name), gcnew String(key), gcnew String(value));
}
//------------------------------------------------------------------------------------


MACRO_DLL int DoString(const TCHAR *szexpression) {
	SetModuleFullPath();
	return ILmStaticLib::DoString(gcnew String(szexpression));
}

MACRO_DLL int DoFile(const TCHAR *szfilename) {
	SetModuleFullPath();
	return ILmStaticLib::DoFile(gcnew String(szfilename));
}

MACRO_DLL int DestroyScope() {
	return ILmStaticLib::DestroyScope();
}

MACRO_DLL int DllDetachFunc_After_Hm866() {
	return DestroyScope();
}