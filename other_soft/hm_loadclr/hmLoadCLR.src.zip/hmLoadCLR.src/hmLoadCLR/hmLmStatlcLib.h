#pragma once

using namespace System;


// dynamic�^�𗘗p���Ȃ����́Bdynamic���Ăяo�������B�������邱�ƂŁAC++�ƃ����N���邱�Ƃ��ł���(���\�b�h�̌������킹�邱�Ƃ��o����)
public ref class ILmStaticLib
{
public:
	static void OutputDebugStream(String^ error);

	static int CreateScope();

	static int BindDllHandle(int dll);

	static void SetCodePage(int cp);

	static void SetModuleFullPath(String^ exe_full_path);

	//-----------------------------------------------------------------
	static int GetNumVar(String^ mng_var_name);

	static int SetNumVar(String^ mng_var_name, int value);

	static int SetTmpNumVar(int value);

	static String^ GetStrVar(String^ mng_var_name);

	static int SetStrVar(String^ mng_var_name, String^ value);

	static int SetTmpStrVar(String^ value);
	//-----------------------------------------------------------------

	//-----------------------------------------------------------------
	static int GetNumItemOfList(String^ mng_arr_name, int index);

	static int SetNumItemOfList(String^ mng_arr_name, int index, int value);

	static String^ GetStrItemOfList(String^ mng_arr_name, int index);

	static int SetStrItemOfList(String^ mng_arr_name, int index, String^ value);
	//-----------------------------------------------------------------

	//-----------------------------------------------------------------
	static int GetNumItemOfDict(String^ mng_arr_name, String^ key);

	static int SetNumItemOfDict(String^ mng_arr_name, String^ key, int value);

	static String^ GetStrItemOfDict(String^ mng_arr_name, String^ key);

	static int SetStrItemOfDict(String^ mng_arr_name, String^ key, String^ value);
	//-----------------------------------------------------------------


	static int DoString(String^ expression);

	static int DoFile(String^ filename);

	static int DestroyScope();

};
