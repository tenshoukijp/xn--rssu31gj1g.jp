﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Neo.Lua")]
[assembly: AssemblyDescription("Lua Language for DLR")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("a00ebc30-1841-4ef8-8ebe-1431933c4b7f")]
