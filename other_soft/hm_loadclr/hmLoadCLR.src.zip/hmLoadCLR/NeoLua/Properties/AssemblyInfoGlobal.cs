﻿using System.Reflection;

[assembly: AssemblyCompany("TecWare Gesellschaft für Softwareentwicklung mbH")]
[assembly: AssemblyProduct("Neo.Lua")]
[assembly: AssemblyCopyright("Copyright © 2013-2015")]
[assembly: AssemblyTrademark("")]

[assembly: AssemblyVersion("5.3.0.0")]
[assembly: AssemblyFileVersion("0.9.17.0")]
