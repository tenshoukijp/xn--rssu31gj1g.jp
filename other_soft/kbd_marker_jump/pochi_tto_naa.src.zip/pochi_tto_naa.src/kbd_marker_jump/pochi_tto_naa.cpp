#include <map>
#include <fstream>
#include <sstream>
#include <shlwapi.h>
#include <regex>
#include <locale.h>
#include <tchar.h>

#include "dllmain.h"


using namespace std;

struct KMJ_DataType {
	int ID;
	int iPosX;
	int iPosY;
	int hWndHide;
	wstring szFileNameFullPath;
	int iSplitMode;
};

static map<int, KMJ_DataType> kmj_HashMap;

wstring KMJ_GetSelfTxtFullPath() {
	wstring dllname = GetSelfDllFullPath();
	TCHAR szDllName[MAX_PATH] = _T("");
	wcscpy_s(szDllName, dllname.data());
	BOOL s = PathRenameExtension(szDllName, _T(".txt"));
	if (s) {
		return wstring(szDllName);
	}
	else {
		return dllname + _T(".txt");
	}
}

static bool isReadedMarkerSaveFile = false;

static bool KMJ_ReadMarkerSaveFile() {
	wstring szFileName = KMJ_GetSelfTxtFullPath();
	if (!PathFileExists(szFileName.data())) {
		FILE* dummy = _wfopen(szFileName.data(), _T("wt, ccs=UNICODE"));
		ofstream ofs(dummy);

		if (ofs.fail()) {
			return false;
		}

		// ��t�@�C�������̂�
		ofs.close();
	}

	FILE* file = _wfopen(szFileName.data(), _T("rt, ccs=UNICODE"));
	wifstream ifs(file);

	if (ifs.fail()) {
		return false;
	}

	wstring bufline;

	while (ifs && getline(ifs, bufline)) {
		// ID,X���W,Y���W,�t���t�@�C���p�X��
		const wregex wre(_T("^([^,]+?),([^,]+?),([^,]+?),([^,]+),([^,]+),([^,]+)$"));
		std::wsmatch wmt;
		if (std::regex_search(bufline, wmt, wre)) {
			// ID
			wstring strID = wmt[1];
			int iID = 0;
			try { iID = std::stoi(strID); }
			catch (...) {}

			// ���WX
			wstring strPosX = wmt[2];
			int iPosX = 0;
			try { iPosX = std::stoi(strPosX); }
			catch (...) {}

			// ���WX
			wstring strPosY = wmt[3];
			int iPosY = 0;
			try { iPosY = std::stoi(strPosY); }
			catch (...) {}

			// ���WX
			wstring hStrWndHandle = wmt[4];
			int iWndHandle = 0;
			try { iWndHandle = std::stoi(hStrWndHandle); }
			catch (...) {}


			// �t�@�C����
			wstring strFileName = wmt[5];

			// �����Ȃ��A�㉺�A���E
			wstring strSplitMode = wmt[6];
			int iSplitMode = 0;
			try { iSplitMode = std::stoi(strSplitMode); }
			catch (...) {}

			// �K�{�ȃf�[�^�͓����Ă���
			if (strID.length() > 0 && strFileName.length() > 0) {
				// �t�@�C���͑��݂��Ă���
				KMJ_DataType data = { iID, iPosX, iPosY, iWndHandle, strFileName, iSplitMode };
				kmj_HashMap[iID] = data;
			}
		}
	}

	ifs.close();

	isReadedMarkerSaveFile = true;
	return true;
}

static bool KMJ_WriteMarkerSaveFile(KMJ_DataType curdata) {
	FILE* file = _wfopen(KMJ_GetSelfTxtFullPath().data(), _T("wt, ccs=UNICODE"));
	wofstream ofs(file);

	if (ofs.fail()) {
		return false;
	}

	for (auto elem : kmj_HashMap) {
		auto data = elem.second;
		wstringstream ss;
		ss << data.ID << "," << data.iPosX << "," << data.iPosY << "," << data.hWndHide << "," << data.szFileNameFullPath << "," << data.iSplitMode;
		wstring line = ss.str();
		ofs << line << endl;
	}

	ofs.close();

	return true;
}

int __cdecl KMJ_StockMarker(int iInputKeyID, int iPosX, int iPosY, int hWndHide, const TCHAR *szFileFullPath, int iSplitMode) {

	// ����
	if (KMJ_ReadMarkerSaveFile()) {

		// ����̃f�[�^��ǉ����āc
		KMJ_DataType curdata = { iInputKeyID, iPosX, iPosY, hWndHide, wstring(szFileFullPath), iSplitMode };
		kmj_HashMap[curdata.ID] = curdata;

		KMJ_WriteMarkerSaveFile(curdata);
	}

	return TRUE;
}

int __cdecl KMJ_GetPosX(int iInputKeyID) {
	if (isReadedMarkerSaveFile || KMJ_ReadMarkerSaveFile()) {
		if (kmj_HashMap[iInputKeyID].ID == iInputKeyID) {
			return kmj_HashMap[iInputKeyID].iPosX;
		}
	}
	return 0;
}

int __cdecl KMJ_GetPosY(int iInputKeyID) {
	if (isReadedMarkerSaveFile || KMJ_ReadMarkerSaveFile()) {
		if (kmj_HashMap[iInputKeyID].ID == iInputKeyID) {
			return kmj_HashMap[iInputKeyID].iPosY;
		}
	}
	return 0;
}

int __cdecl KMJ_GetWindowHandle(int iInputKeyID) {
	if (isReadedMarkerSaveFile || KMJ_ReadMarkerSaveFile()) {
		if (kmj_HashMap[iInputKeyID].ID == iInputKeyID) {
			TCHAR szClassName[1024];
			GetClassName((HWND)kmj_HashMap[iInputKeyID].hWndHide, szClassName, sizeof(szClassName));    // �N���X������̎擾
			// �G�ۂ̗L���ȃE�B���h�E�n���h���ł���B
			if (wcsstr(szClassName, _T("maru"))) {
				return kmj_HashMap[iInputKeyID].hWndHide;
			}
			NULL;
		}
	}
	return NULL;
}

const TCHAR* __cdecl KMJ_GetFileFullPath(int iInputKeyID) {
	if (isReadedMarkerSaveFile || KMJ_ReadMarkerSaveFile()) {
		if (kmj_HashMap[iInputKeyID].ID == iInputKeyID) {
			return kmj_HashMap[iInputKeyID].szFileNameFullPath.data();
		}
	}
	return NULL;
}

int __cdecl KMJ_GetSplitMode(int iInputKeyID) {
	if (isReadedMarkerSaveFile || KMJ_ReadMarkerSaveFile()) {
		if (kmj_HashMap[iInputKeyID].ID == iInputKeyID) {
			return kmj_HashMap[iInputKeyID].iSplitMode;
		}
	}
	return NULL;
}

