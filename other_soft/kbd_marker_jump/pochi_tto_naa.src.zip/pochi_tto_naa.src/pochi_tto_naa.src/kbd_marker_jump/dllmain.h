#include <windows.h>

using namespace std;

extern wstring GetSelfDllFullPath();
