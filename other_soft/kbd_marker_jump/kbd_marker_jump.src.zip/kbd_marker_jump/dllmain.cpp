#include "dllmain.h"

#pragma comment(lib, "shlwapi.lib")

static char szMySelfFileName[1024];
string GetSelfDllFullPath() {
	return szMySelfFileName;
}


BOOL APIENTRY DllMain(HANDLE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved ) {

	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		// ���g�̖��O�̊i�[
		GetModuleFileName((HMODULE)hModule, szMySelfFileName, sizeof(szMySelfFileName) / sizeof(szMySelfFileName[0]));

		// �S�Ԋm��
		onig_init();

		break;
	case DLL_THREAD_ATTACH:
		break;
	case DLL_THREAD_DETACH:
		break;
	case DLL_PROCESS_DETACH:

		// �S�ԉ��
		onig_end();

		break;

	default:
		break;
	}
	return TRUE;
}

