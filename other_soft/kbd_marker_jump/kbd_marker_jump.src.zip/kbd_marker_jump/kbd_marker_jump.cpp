#include <fstream>
#include <sstream>
#include <shlwapi.h>

#include "dllmain.h"


struct KMJ_DataType {
	int ID;
	int iPosX;
	int iPosY;
	int hWndHide;
	string szFileNameFullPath;
	int iSplitMode;
};

static map<int, KMJ_DataType> kmj_HashMap;

string KMJ_GetSelfTxtFullPath() {
	string dllname = GetSelfDllFullPath();
	MatchResult mt;
	if (Is_OnigRegex(dllname, "^(.+?)\\.[dD][lL][lL]$", &mt)) {
		string dllname_without_ext = mt[1];
		return dllname_without_ext + ".txt";
	} else {
		return dllname + ".txt";
	}
}

static bool isReadedMarkerSaveFile = false;

static bool KMJ_ReadMarkerSaveFile() {
	string szFileName = KMJ_GetSelfTxtFullPath();
	if (! PathFileExists( szFileName.data() ) ) {
		ofstream ofs(szFileName);

		if (ofs.fail()) {
			return false;
		}

		// ��t�@�C�������̂�
		ofs.close();
	}

	ifstream ifs(szFileName);

	if (ifs.fail()) {
		return false;
	}

	string bufline;

	while (ifs && getline(ifs, bufline)) {
		// ID,X���W,Y���W,�t���t�@�C���p�X��
		MatchResult mt;
		if (Is_OnigRegex(bufline, "^([^,]+?),([^,]+?),([^,]+?),([^,]+),([^,]+),([^,]+)$", &mt)) {
			// ID
			string strID = mt[1];
			int iID = 0;
			try { iID = std::stoi(strID); }
			catch (...) {}

			// ���WX
			string strPosX = mt[2];
			int iPosX = 0;
			try { iPosX = std::stoi(strPosX); }
			catch (...) {}

			// ���WX
			string strPosY = mt[3];
			int iPosY = 0;
			try { iPosY = std::stoi(strPosY); }
			catch (...) {}

			// ���WX
			string hStrWndHandle = mt[4];
			int iWndHandle = 0;
			try { iWndHandle = std::stoi(hStrWndHandle); }
			catch (...) {}


			// �t�@�C����
			string strFileName = mt[5];

			// �����Ȃ��A�㉺�A���E
			string strSplitMode = mt[6];
			int iSplitMode = 0;
			try { iSplitMode = std::stoi(strSplitMode); }
			catch (...) {}

			// �K�{�ȃf�[�^�͓����Ă���
			if (strID.length() > 0 && strFileName.length() > 0) {
				// �t�@�C���͑��݂��Ă���
				KMJ_DataType data = { iID, iPosX, iPosY, iWndHandle, strFileName, iSplitMode };
				kmj_HashMap[iID] = data;
			}
		}
	}

	ifs.close();

	isReadedMarkerSaveFile = true;
	return true;
}

static bool KMJ_WriteMarkerSaveFile(KMJ_DataType curdata) {
	ofstream ofs(KMJ_GetSelfTxtFullPath());

	if (ofs.fail()) {
		return false;
	}

	for (auto elem : kmj_HashMap) {
		auto data = elem.second;
		stringstream ss;
		ss << data.ID << "," << data.iPosX << "," << data.iPosY << "," << data.hWndHide << "," << data.szFileNameFullPath << "," << data.iSplitMode;
		string line = ss.str();
		ofs << line << endl;
	}

	ofs.close();

	return true;
}

int __cdecl KMJ_StockMarker(int iInputKeyID, int iPosX, int iPosY, int hWndHide, const char *szFileFullPath, int iSplitMode) {

	// ����
	if (KMJ_ReadMarkerSaveFile()) {

		// ����̃f�[�^��ǉ����āc
		KMJ_DataType curdata = { iInputKeyID, iPosX, iPosY, hWndHide, string(szFileFullPath), iSplitMode };
		kmj_HashMap[curdata.ID] = curdata;

		KMJ_WriteMarkerSaveFile(curdata);
	}

	return TRUE;
}

int __cdecl KMJ_GetPosX(int iInputKeyID) {
	if (isReadedMarkerSaveFile || KMJ_ReadMarkerSaveFile()) {
		if (kmj_HashMap[iInputKeyID].ID == iInputKeyID) {
			return kmj_HashMap[iInputKeyID].iPosX;
		}
	}
	return 0;
}

int __cdecl KMJ_GetPosY(int iInputKeyID) {
	if (isReadedMarkerSaveFile || KMJ_ReadMarkerSaveFile()) {
		if (kmj_HashMap[iInputKeyID].ID == iInputKeyID) {
			return kmj_HashMap[iInputKeyID].iPosY;
		}
	}
	return 0;
}

int __cdecl KMJ_GetWindowHandle(int iInputKeyID) {
	if (isReadedMarkerSaveFile || KMJ_ReadMarkerSaveFile()) {
		if (kmj_HashMap[iInputKeyID].ID == iInputKeyID) {
			return kmj_HashMap[iInputKeyID].hWndHide;
		}
	}
	return NULL;
}

const char* __cdecl KMJ_GetFileFullPath(int iInputKeyID) {
	if (isReadedMarkerSaveFile || KMJ_ReadMarkerSaveFile()) {
		if (kmj_HashMap[iInputKeyID].ID == iInputKeyID) {
			return kmj_HashMap[iInputKeyID].szFileNameFullPath.data();
		}
	}
	return NULL;
}

int __cdecl KMJ_GetSplitMode(int iInputKeyID) {
	if (isReadedMarkerSaveFile || KMJ_ReadMarkerSaveFile()) {
		if (kmj_HashMap[iInputKeyID].ID == iInputKeyID) {
			return kmj_HashMap[iInputKeyID].iSplitMode;
		}
	}
	return NULL;
}
