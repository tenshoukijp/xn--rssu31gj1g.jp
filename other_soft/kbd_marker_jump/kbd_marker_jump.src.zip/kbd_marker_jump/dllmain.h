#include <windows.h>

#include "OnigRegex.h"

using namespace std;

extern string GetSelfDllFullPath();
