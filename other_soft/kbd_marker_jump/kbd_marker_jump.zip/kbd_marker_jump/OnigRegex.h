#pragma once

#include <string>
#include <map>

#include "oniguruma/oniguruma.h"

using namespace std;

typedef map<int, string> MatchResult;
int Is_OnigRegex( string str_target, string str_regex, MatchResult *matches=NULL );
