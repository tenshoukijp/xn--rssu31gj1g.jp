#include <string>
#include <tchar.h>

namespace std {
	using tstring = std::basic_string<TCHAR>;
}
System::String^ string_to_String(std::tstring str);
std::tstring String_to_string(System::String^ str);