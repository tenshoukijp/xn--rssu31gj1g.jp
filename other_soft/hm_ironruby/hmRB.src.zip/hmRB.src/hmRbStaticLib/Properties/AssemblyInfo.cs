﻿using System.Reflection;
using System.Runtime.InteropServices;


[assembly: ComVisible(false)]

// 次の GUID は、このプロジェクトが COM に公開される場合の、typelib の ID です
[assembly: Guid("d976ec5e-8310-4212-a205-3d70f7cd295c")]

[assembly: AssemblyVersion("1.4.5.1")]
[assembly: AssemblyFileVersion("1.4.5.1")]
