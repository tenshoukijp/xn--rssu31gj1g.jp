#include <windows.h>
#include <string>
#include "string_converter.h"

using namespace System;


void OutputDebugStream(String^ message) {
	std::tstring std_message = String_to_string(message);
	OutputDebugString(std_message.data());
}