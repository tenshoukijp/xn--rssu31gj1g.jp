#include <windows.h>
#include <string>
#include <map>

#include "outputdebugstream.h"
#include "string_converter.h"
#include "hmRbStatlcLib.h"

#define MACRO_DLL extern "C" __declspec(dllexport)

using namespace std;
using namespace System;



//------------------------------------------------------------------------------------
MACRO_DLL int GetNumVar(const char *sz_var_name) {
	return IRbStaticLib::GetNumVar(gcnew String(sz_var_name));
}

MACRO_DLL int SetNumVar(const char *sz_var_name, int value) {
	return IRbStaticLib::SetNumVar(gcnew String(sz_var_name), value);
}

// �G�ۂ̃L���b�V���̂���
string strvars;
MACRO_DLL const char * GetStrVar(const char *sz_var_name) {
	auto var = IRbStaticLib::GetStrVar(gcnew String(sz_var_name));
	strvars = String_to_string(var->ToString());
	return strvars.data();
}

MACRO_DLL int SetStrVar(const char *sz_var_name, const char *value) {
	return IRbStaticLib::SetStrVar(gcnew String(sz_var_name), gcnew String(value));
}
//------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------
MACRO_DLL int GetNumItemOfList(const char *sz_arr_name, const int index) {
	return IRbStaticLib::GetNumItemOfList(gcnew String(sz_arr_name), index);
}

MACRO_DLL int SetNumItemOfList(const char *sz_arr_name, const int index, const int value) {
	return IRbStaticLib::SetNumItemOfList(gcnew String(sz_arr_name), index, value);
}

// �G�ۂ̃L���b�V���̂���
string strvarsoflist;
MACRO_DLL const char * GetStrItemOfList(const char *sz_arr_name, const int index) {
	auto var = IRbStaticLib::GetStrItemOfList(gcnew String(sz_arr_name), index);
	strvarsoflist = String_to_string(var->ToString());
	return strvarsoflist.data();
}

MACRO_DLL int SetStrItemOfList(const char *sz_arr_name, const int index, const char* value) {
	return IRbStaticLib::SetStrItemOfList(gcnew String(sz_arr_name), index, gcnew String(value));
}
//------------------------------------------------------------------------------------



//------------------------------------------------------------------------------------
MACRO_DLL int GetNumItemOfDict(const char *sz_arr_name, const char *key) {
	return IRbStaticLib::GetNumItemOfDict(gcnew String(sz_arr_name), gcnew String(key));
}

MACRO_DLL int SetNumItemOfDict(const char *sz_arr_name, const char *key, const int value) {
	return IRbStaticLib::SetNumItemOfDict(gcnew String(sz_arr_name), gcnew String(key), value);
}

// �G�ۂ̃L���b�V���̂���
string strvarsofdict;
MACRO_DLL const char * GetStrItemOfDict(const char *sz_arr_name, const char *key) {
	auto var = IRbStaticLib::GetStrItemOfDict(gcnew String(sz_arr_name), gcnew String(key));
	strvarsofdict = String_to_string(var->ToString());
	return strvarsofdict.data();
}

MACRO_DLL int SetStrItemOfDict(const char *sz_arr_name, const char *key, const char* value) {
	return IRbStaticLib::SetStrItemOfDict(gcnew String(sz_arr_name), gcnew String(key), gcnew String(value));
}
//------------------------------------------------------------------------------------


MACRO_DLL int DoString(char *szexpression) {
	return IRbStaticLib::DoString(gcnew String(szexpression));
}

MACRO_DLL int DoFile(char *szfilename) {
	return IRbStaticLib::DoFile(gcnew String(szfilename));
}
