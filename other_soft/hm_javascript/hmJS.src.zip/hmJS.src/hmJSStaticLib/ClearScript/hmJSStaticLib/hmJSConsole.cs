﻿using System;

// Consoleのチープクラス
public partial class hmJSDynamicLib
{
    public static hmJSConsole console;

    public class hmJSConsole
    {
        public static void log(params Object[] expressions)
        {
            Hidemaru.debuginfo(expressions);
        }

        public static void debug(params Object[] expressions)
        {
            Hidemaru.debuginfo(expressions);
        }

        public static void error(params Object[] expressions)
        {
            Hidemaru.debuginfo(expressions);
        }

        public static void clear(params Object[] expressions)
        {
            Hidemaru.debuginfo("\n\n");
        }

        public static void info(params Object[] expressions)
        {
            Hidemaru.debuginfo(expressions);
        }

        public static void trace(params Object[] expressions)
        {
            Hidemaru.debuginfo(expressions);
        }

        public static void warn(params Object[] expressions)
        {
            Hidemaru.debuginfo(expressions);
        }

        public static void assert(params Object[] expressions)
        {
            if (expressions.Length > 0)
            {
                // 最初がFalse
                if ((Boolean)expressions[0] == false)
                {
                    Hidemaru.debuginfo(expressions);
                }
            }
        }
    }
}