﻿using System;
using System.Reflection;

public partial class hmJSDynamicLib
{
    public class DllPathResolver
    {
        public DllPathResolver()
        {
            AppDomain.CurrentDomain.AssemblyResolve += CurrentDomain_AssemblyResolve;
        }

        ~DllPathResolver()
        {
            AppDomain.CurrentDomain.AssemblyResolve -= CurrentDomain_AssemblyResolve;
        }

        private static Assembly CurrentDomain_AssemblyResolve(object sender, ResolveEventArgs args)
        {
            try
            {
                var requestingAssembly = args.RequestingAssembly;
                var requestedAssembly = new AssemblyName(args.Name);

                // カレントディレクトリの.dllのファイル名部分だけを指定している場合
                String currentmacrodirectory = (String)Hidemaru.Macro.Var("currentmacrodirectory");
                var targetName = currentmacrodirectory + @"\" + requestedAssembly.Name + ".dll";
                if (System.IO.File.Exists(targetName))
                {
                    return Assembly.LoadFile(targetName);
                }

                // そのようなフルパスが指定されている場合
                targetName = requestedAssembly.Name;
                if (System.IO.File.Exists(targetName))
                {
                    return Assembly.LoadFile(targetName);
                }
            }
            catch
            {
                return null;
            }
            return null;
        }
    }
}
